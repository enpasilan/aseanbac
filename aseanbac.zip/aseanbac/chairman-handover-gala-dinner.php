<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>
            
            <div class="row">
            	<div class="span5">
                	
                    <h1><strong>About ASEAN-BAC 2015 Chairmanship Handover Gala Dinner</strong></h1>
                        <p>2015 was a key milestone year for ASEAN as the official formation year of the ASEAN Economic Community (AEC). The AEC Blueprint implementation had been gaining significant momentum and global attention over the years, and its completion in 2015 was highly anticipated and widely regarded as an especially important year for the ASEAN Community.</p>
			<p>ASEAN-BAC Malaysia as Chairman in this pivotal year looked to enhance awareness and connectivity with the private sector through the organisation of various official programmes and conferences throughout the year.</p>
			<p>To commemorate the handover of the ASEAN-BAC Chairmanship from Myanmar (2014) to Malaysia (2015), ASEAN-BAC Malaysia organised the official ASEAN-BAC 2015 Chairmanship Handover Ceremony Gala Dinner and the ASEAN SME Conference. The Handover Ceremony was held at the KL Hilton on the 19th of November 2014 and was witnessed by the Prime Minister of Malaysia, YAB Dato' Sri Najib Tun Razak.</p>
			<p>Other distinguished dignitaries who witnessed the ceremony include ASEAN-BAC Council Members, Malaysian Minister of International Trade and Industry, YB Dato' Sri Mustapa Mohamed and ASEAN Ambassadors and High Commissioners.</p>
			<p><a href='Gallery-Event-1.html' class='btn text-uppercase'>View Photo Gallery</a></p>
                    
                </div><!-- end .span5 -->
                <div class="span7">
                	
                    <div class="portfolio-item-slider">
                    	
                        <ul class="slides">
                        	<li>
                            	
                                <img src="_content/events/670x670-galadinner.jpg" alt="handover gala dinner">
                                
                                <div class="slidetext">
                                	<h2><strong>Gala Dinner</strong></h2>
                                </div><!-- end .slidetext -->
                                
                            </li>
 
                        </ul>
                        
                    </div><!-- end .portfolio-item-slider -->
                    
                </div><!-- end .span7 -->
            </div><!-- end .row -->
 
            
 
		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

		</div><!-- end #content -->
<?php include "footer.php"; ?>