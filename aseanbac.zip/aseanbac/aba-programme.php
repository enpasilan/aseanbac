<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>ASEAN Business Awards (ABA) Gala Dinner</h1><br/><br/>
			<p>PROGRAMME</p>
			<p>20th November 2015<br/>Shangri-La Hotel Kuala Lumpur, Malaysia</p>
			<table class="table-bordered table-striped" width="100%">
				<tbody>
				<thead>
					<tr>
						<th width="250">Time</th>
						<th>Programme</th>
					</tr>
				</thead>
					<tr>
						<td>18:30pm</td>
						<td>
							<ul>
								<li>Arrival of Guests &amp; Media</li>
								<li>Cocktail Reception and Foyer Entertainment</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>19:15pm</td>
						<td>
							<ul>
								<li>Arrival of VVIPs</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>19:30pm</td>
						<td>
							<ul>
								<li>Welcome Remarks by Chairman of ASEAN Business Advisory Council,<br />
									Tan Sri Dato' Dr. Mohd Munir Abdul Majid</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>19:35pm</td>
						<td>
							<ul>
								<li>Gala Dinner Opening Gambit</li>
								<li>Dinner &amp; Entertainment</li>
								<li>Food presentation</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>20:25pm</td>
						<td>
							<ul>
								<li>ASEAN Business Awards Presentation</li>
								<li>Group Photo with all 21 ABA recipients</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>20:40pm</td>
						<td>
							<ul>
								<li>Presentation of the ASEAN-BAC ASEAN Lifetime Achievement Award</li>
								<li>Entertainment</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>21:10pm</td>
						<td>
							<ul>
								<li>Launch of the ASEAN Young Entrepreneurs Council (AYEC)</li>
							</ul>
						</td>
					</tr>
					<tr>
						<td>21:15-22:00pm</td>
						<td>
							<ul>
								<li>Entertainment</li>
								<li>Closing Remarks</li>
								<li>Ends</li>
							</ul>
						</td>
					</tr>
				</tbody>
			</table>
			<div style="width: 100%; text-align: right;">*This programme is subject to changes<br />
				The ASEAN Business Advisory Council (ABAC) reserves the right to amend the programme and is<br />
				not responsible for cancellations due to unforeseen circumstances.</div>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>