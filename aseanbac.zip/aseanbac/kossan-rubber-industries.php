<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>KOSSAN RUBBER INDUSTRIES</h2>
               <div class="post-2176 page type-page status-publish hentry text-edit">
            
<p>KOSSAN RUBBER INDUSTRIES BHD was established in 1979 by its Founder and Group Managing Director, Dato� KS Lim. Kossan has emerged today as one of the world�s largest manufacturers well known for its diversified product range of natural and synthetic rubber disposable gloves with annual production capacity exceeding 22 billion pieces, and still expanding.</p>
<p>Kossan also manufactures a wide range of engineering rubber products for automotive, general industries and infrastructure application such as fenders, seismic and bridge bearing. Kossan is a public listed company on the Main Market of Bursa Malaysia since 1996 and has been classified as one of the fastest growing companies in Malaysia. Since its humble beginning in 1979 with a five-man operation, the Group has grown from strength to strength to its current world-class multi-products company with a workforce of over 5,000 and revenue exceeding RM1.30 billion in year 2014.</p>
<p>Kossan has maintained an unbroken profit record for the past 18 years since listing. Kossan remains cautious with the ever challenging operating environment and continues to place concerted efforts to strengthen internal competencies through innovation. Research and development, production process optimisation, automation, business processes computerisation and human capital development are the key areas of focus. Coupled with its dynamic and practical business model and committed management team, Kossan stretches beyond limits to meet evolving changes in demand.</p>
<p>Kossan always seek to add value by aligning sustainable values with its corporate mission and in delivering consistent results exceeding expectations to business partners and shareholders present and in the future.</p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>