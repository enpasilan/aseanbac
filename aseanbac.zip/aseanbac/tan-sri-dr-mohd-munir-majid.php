<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Tan Sri Dr Mohd Munir Majid</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="tsmunir" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Tan Sri Dr. Mohd Munir Abdul Majid</strong>
					<br>
					2015 Chairman of ASEAN Business
					<br/>
					Advisory Council (ASEAN-BAC)
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Tan Sri Dr Munir Majid obtained a B.Sc (Econ) from the London School of Economics and Political Science (LSE) in 1971 where he also obtained his Ph.D in International Relations in 1978. He taught at the Department of International Relations in LSE from 1972-1975.</p>
			<p>Dr Munir joined the New Straits Times (NST) at the end of 1978 as leader writer and progressed to become Group Editor. He left NST in 1986 to become CEO of a small merchant bank, Pertanian Baring Sanwa (PBS), whose name he changed to Commerce International Merchant Bankers (CIMB) which was then transformed into one of Malaysia's leading merchant banks. He was invited by the Government of Malaysia to establish and become the first and founding Executive Chairman of the Securities Commission in 1993, where he served for two terms until 1999.</p>
			<p>After leaving the Securities Commission, he served as Senior Independent Non-Executive Director of Telekom Malaysia Berhad for 4 years until June 2004, and was Chairman of its mobile subsidiary Celcom (M) Berhad from 2002-2004. In June 2004, Dr Munir joined the Malaysia Airlines Board of Directors and in August that year was appointed its Non-Executive Chairman till July 2011.</p>
			<p>He became Chairman of Bank Muamalat Malaysia Berhad, an Islamic financial institution, in 2008. In February 2014 Dr. Munir was appointed chairman of CIMB Asean Research Institute and also joined the board of the Institute of Strategic and International Studies (ISIS) Malaysia. He is on the Financial Services Talent Council of Bank Negara Malaysia. As co-chair of the Malaysia-America Foundation, he works to deepen relations between the two countries.</p>
			<p>Dr. Munir was the founder President of the Kuala Lumpur Business Club (2003-2008). In May 2004, he was appointed a member of the Court of Fellows of the Malaysian Institute of Management.</p>
			<p>In December 2005, he was made an Honorary Fellow of the LSE and in 2008 he was appointed Visiting Senior Fellow at LSE IDEAS (Centre for International Affairs, Diplomacy and Strategy) where he started the Southeast Asia International Affairs Programme and headed it until 2012. He has written for IDEAS publications and published in International Politics, a British academic journal.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>