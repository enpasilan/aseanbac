<div id="footer">

	<!-- /// FOOTER     ///////////////////////////////////////////////////////////////////////////////////////////////////////// -->

	<div id="footer-top">

		<!-- /// FOOTER-TOP     ///////////////////////////////////////////////////////////////////////////////////////////////// -->	



		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->    

	</div><!-- end #footer-top -->

	<div id="footer-bottom">

		<!-- /// FOOTER-BOTTOM     ////////////////////////////////////////////////////////////////////////////////////////////// -->	

		<div class="row">
			<div class="span6" id="footer-bottom-widget-area-1">

				<div class="widget widget_text">

					<div class="textwidget">

						<p class="last">All Rights Reserved ASEAN BAC Malaysia 2016. Designed by <a href="http://sienna-dmb.com" target="_blank">Sienna DMB</a></p>

					</div><!-- end .textwidget -->

				</div><!-- end .widget_text -->

			</div><!-- end .span6 -->

		</div><!-- end .row -->
		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->    

	</div><!-- end #footer-bottom -->

	<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

</div><!-- end #footer -->

</div><!-- end #wrap -->

<a id="back-to-top" href="#">
	<i class="fa fa-angle-up"></i>
</a>

<!-- /// jQuery ////////  -->
<script src="http://aseanbac.com.my/_layout/js/jquery-2.1.1.min.js"></script>

<!-- /// ViewPort ////////  -->
<script src="http://aseanbac.com.my/_layout/js/viewport/jquery.viewport.js"></script>

<!-- /// Easing ////////  -->
<script src="http://aseanbac.com.my/_layout/js/easing/jquery.easing.1.3.js"></script>

<!-- /// SimplePlaceholder ////////  -->
<script src="http://aseanbac.com.my/_layout/js/simpleplaceholder/jquery.simpleplaceholder.js"></script>

<!-- /// Fitvids ////////  -->
<script src="http://aseanbac.com.my/_layout/js/fitvids/jquery.fitvids.js"></script>

<!-- /// Animations ////////  -->
<script src="http://aseanbac.com.my/_layout/js/animations/animate.js"></script>

<!-- /// Superfish Menu ////////  -->
<script src="http://aseanbac.com.my/_layout/js/superfish/hoverIntent.js"></script>
<script src="http://aseanbac.com.my/_layout/js/superfish/superfish.js"></script>

<!-- /// Revolution Slider ////////  -->
<script src="http://aseanbac.com.my/_layout/js/revolutionslider/js/jquery.themepunch.plugins.min.js"></script>
<script src="http://aseanbac.com.my/_layout/js/revolutionslider/js/jquery.themepunch.revolution.min.js"></script>

<!-- /// bxSlider ////////  -->
<script src="http://aseanbac.com.my/_layout/js/bxslider/jquery.bxslider.min.js"></script>

<!-- /// Magnific Popup ////////  -->
<script src="http://aseanbac.com.my/_layout/js/magnificpopup/jquery.magnific-popup.min.js"></script>

<!-- /// Isotope ////////  -->
<script src="http://aseanbac.com.my/_layout/js/isotope/imagesloaded.pkgd.min.js"></script>
<script src="http://aseanbac.com.my/_layout/js/isotope/isotope.pkgd.min.js"></script>

<!-- /// Parallax ////////  -->
<script src="http://aseanbac.com.my/_layout/js/parallax/jquery.parallax.min.js"></script>
<script src="http://aseanbac.com.my/_layout/js/parallax/jquery.parallax-mousemoving.min.js"></script>

<!-- /// EasyPieChart ////////  -->
<script src="http://aseanbac.com.my/_layout/js/easypiechart/jquery.easypiechart.min.js"></script>

<!-- /// YTPlayer ////////  -->
<script src="http://aseanbac.com.my/_layout/js/itplayer/jquery.mb.YTPlayer.js"></script>

<!-- /// Easy Tabs ////////  -->
<script src="http://aseanbac.com.my/_layout/js/easytabs/jquery.easytabs.min.js"></script>	

<!-- /// Waypoints ////////  -->
<script src="http://aseanbac.com.my/_layout/js/waypoints/waypoints.min.js"></script>

<!-- /// Form validate ////////  -->
<script src="http://aseanbac.com.my/_layout/js/jqueryvalidate/jquery.validate.min.js"></script>

<!-- /// Form submit ////////  -->
<script src="http://aseanbac.com.my/_layout/js/jqueryform/jquery.form.min.js"></script>

<!-- /// gMap ////////  -->
<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script src="_layout/js/gmap/jquery.gmap.min.js"></script>

<!-- /// Twitter ////////  -->
<script src="http://aseanbac.com.my/_layout/js/twitter/twitterfetcher.js"></script>

<!-- /// Custom JS ////////  -->
<script src="http://aseanbac.com.my/_layout/js/scripts.js"></script>
<script src="http://aseanbac.com.my/_layout/js/plugins.js"></script>


<!-- Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-56207872-1', 'auto');
ga('send', 'pageview');
</script>
<!-- End Google Analytics -->

</body>
</html>