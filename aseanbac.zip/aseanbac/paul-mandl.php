<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Mr Paul Mandl</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Paul Mandl" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Mr Paul Mandl</strong>
					<br>
					Team Leader of the ASEAN Regional Integration Support from the EU (ARISE)
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Mr. Paul Mandl is currently Team Leader of the ASEAN Regional Integration Support from the EU (ARISE) programme, which is a technical co-operation facility with the purpose to support the implementation of key ASEAN regional integration initiatives. During the past 20 years Paul has worked in business development as well as managed complex Technical Cooperation Projects with a focus on trade, economic development, regional integration, economic policy dialogue, trade facilitation.He was the Director of ASEAN-EU Programme for Regional Integration Support (APRIS) II from 2009 to 2011 and the Director of the Centre for Trade and Regional Integration from 2007 to 2012. Prior to this he worked in the private sector notably Unilever in the food and agribusiness sectors.</p>
			<p>Paul holds a Master's degree in Agricultural Economics for Developing Countries from University of London and a Post Graduate Diploma in Development Economics from the University of East Anglia.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>