<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Tan Sri Rastam Mohd Isa</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Tan Sri Rastam Mohd Isa" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Tan Sri Rastam Mohd Isa</strong>
					<br>
					Chairman and Chief Executive of the Institute of Strategic and International Studies (ISIS) Malaysia.
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Tan Sri Rastam Mohd Isa is Chairman and Chief Executive of the Institute of Strategic and International Studies (ISIS) Malaysia. He holds a Bachelor of Social Science (Hons) degree from Universiti Sains Malaysia, a Master of Arts degree in International Relations and Strategic Studies from the University of Lancaster and a Certificate of Diplomacy from the University of Oxford.</p>
			<p>Tan Sri Rastam served in various capacities at the Ministry of Foreign Affairs and Malaysian diplomatic missions abroad, including as High Commissioner of Malaysia to Pakistan, Ambassador of Malaysia to Bosnia Herzegovina, Ambassador of Malaysia to the Republic of Indonesia and Permanent Representative of Malaysia to the United Nations in New York. He was Secretary General of the Ministry of Foreign Affairs from 8 January 2006 until he officially retired from public service on 2 September 2010.</p>
			<p>Tan Sri Rastam was Advisor at the Chief Minister's Department in Sarawak from 2010 to 2013. He serves as chairman of the board of directors of one Malaysian public listed company and sits as director on the board of two other companies.</p>
			<p>Tan Sri Rastam is Chairman of the Malaysian National Committee for the Pacific Economic Cooperation Council (PECC) and Chairman of the Malaysian National Committee of the Council for Security Cooperation in the Asia Pacific (CSCAP).</p>
			<p>Tan Sri Rastam is Chairman of the Malaysian National Committee for the Pacific Economic Cooperation Council (PECC) and Chairman of the Malaysian National Committee of the Council for Security Cooperation in the Asia Pacific (CSCAP).</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>