<?php include "header.php"; ?>
<div id="content">
	<br/><br/>

<div class="row">
		<div class="span12">
			<h1>ASEAN Business Awards Malaysia (ABAM) 2015 Recipients</h1><br><br>
<table class="table" width="100%">
<tbody>
<tr>
<td width="30%"><strong>Category</strong></td>
<td width="35%"><strong>Company Name</strong></td>
<td width="&quot;35%"><strong>Recipient Name</strong></td>
</tr>
<tr>
<td>SME EXCELLENCE - INNOVATION</td>
<td>SRI EMAS INTERNATIONAL SCHOOL</td>
<td>MS. ANNE THAM</td>
</tr>
<tr>
<td>SME EXCELLENCE - GROWTH</td>
<td>AMP CORPORATION (M) SDN BHD</td>
<td>YBHG. DATO' HJ MUSTAFFA BIN HJ ABDUL RAHMAN</td>
</tr>
<tr>
<td>SME EXCELLENCE - EMPLOYMENT</td>
<td>ABX EXPRESS ((M) SDN BHD</td>
<td>MR. MOHAMED ALI BIN NOORDIN</td>
</tr>
<tr>
<td>SME EXCELLENCE - CSR</td>
<td>BRICKFIELDS ASIA COLLEGE SDN BHD</td>
<td>MR. RAJA SINGHAM</td>
</tr>
<tr>
<td>INDUSTRY EXCELLENCE - OIL &amp; GAS</td>
<td>PETROLIAM NASIONAL BERHAD (PETRONAS)</td>
<td>YBHG. DATUK WAN ZULKIFLEE WAN ARIFFIN</td>
</tr>
<tr>
<td>INDUSTRY EXCELLENCE - RETAIL</td>
<td>PAVILION KUALA LUMPUR</td>
<td></td>
</tr>
<tr>
<td>AEC PRIORITY INTEGRATION SECTOR EXCELLENCE<br>
TOURISM</td>
<td>SHANGRI-LA HOTELS (M) BERHAD</td>
<td></td>
</tr>
<tr>
<td>AEC PRIORITY INTEGRATION SECTOR EXCELLENCE<br>
RUBBER BASED PRODUCTS</td>
<td>TOP GLOVE CORPORATION BERHAD</td>
<td>YBHG. TAN SRI DATO' SRI DR. LIM WEE CHAI</td>
</tr>
<tr>
<td>AEC PRIORITY INTEGRATION SECTOR EXCELLENCE<br>
HEALTHCARE</td>
<td>PANTAI HOLDINGS BERHAD</td>
<td>MR. AHMAD SHAHIZAM BIN MOHD SHARIFF</td>
</tr>
<tr>
<td>AEC PRIORITY INTEGRATION SECTOR EXCELLENCE<br>
FISHERIES</td>
<td>QL RESOURCES BERHAD</td>
<td>DR. CHIA SONG KUN</td>
</tr>
<tr>
<td>AEC PRIORITY INTEGRATION SECTOR EXCELLENCE<br>
e-ASEAN</td>
<td>AXIATA GROUP BERHAD</td>
<td>YBHG. DATO' SRI JAMALUDIN IBRAHIM</td>
</tr>
<tr>
<td>AEC PRIORITY INTEGRATION SECTOR EXCELLENCE<br>
AVIATION</td>
<td>AIRASIA BERHAD</td>
<td>YBHG. DATUK KAMARUDIN MERANUN</td>
</tr>
<tr>
<td>AEC PRIORITY INTEGRATION SECTOR EXCELLENCE<br>
AUTOMOTIVE</td>
<td>INGRESS CORPORATION BERHAD</td>
<td>YBHG. DATUK HAJI RAMELI BIN MUSA</td>
</tr>
<tr>
<td>AEC PRIORITY INTEGRATION SECTOR EXCELLENCE<br>
AGRICULTURE BASED PRODUCTS</td>
<td>SIME DARBY BERHAD</td>
<td>YBHG. TAN SRI DATO' SERI MOHD BAKKE SALLEH</td>
</tr>
<tr>
<td>ASEAN BUSINESS SUCCESS STORY</td>
<td>GOODWAY INTEGRATED INDUSTRIES BERHAD</td>
<td>MR. BOON WEE TAI</td>
</tr>
<tr>
<td>CEO OF THE YEAR</td>
<td>MALAYAN BANKING BERHAD (MAYBANK)</td>
<td>YBHG. DATUK ABDUL FARID ALIAS</td>
</tr>
<tr>
<td>LIFETIME ACHIEVEMENT AWARD</td>
<td>ROYAL SELANGOR INTERNATIONAL SDN BHD</td>
<td>YBHG. TAN SRI DATUK YONG POH KON</td>
</tr>
</tbody>
</table>
<br/>


<div class="row">
<div class="span12">
<h1>ASEAN Business Awards Malaysia - Past Winners</h1><br/><br/>
<h3>5th INSTALLATION</h3>
<table width="100%" class="table">
<tbody>
<tr>
<td width="30%"><strong>Category</strong></td>
<td width="35%"><strong>Company Name</strong></td>
<td width="&quot;35%"><strong>Recipient Name</strong></td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Naza Group</td>
<td>The Late Tan Sri SM Nasimuddin SM</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Professor Emeritus Tan Sri Dato' Sri Dr Lim Kok Wing</td>
<td>Limkokwing University of Creative Technology</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Permodalan Nasional Berhad</td>
<td>Tun Ahmad Sarji Abdul Hamid</td>
</tr>
<tr>
<td>CEO of the year</td>
<td>Westports Malaysia Sdn Bhd</td>
<td>Tan Sri Datuk G. Gnanalingam</td>
</tr>
<tr>
<td>GLC CEO of the Year</td>
<td>Mydin Mohamed Holdings Berhad</td>
<td>Dato' Hj Ameer Ali bin Mydin</td>
</tr>
<tr>
<td>SME CEO of the Year</td>
<td>Permodalan Nasional Berhad</td>
<td>Tan Sri Hamad Kama Piah Che Othman</td>
</tr>
<tr>
<td>Entreprenuer of the Year</td>
<td>Tanjung Offshore Sdn Bhd</td>
<td>Haji Omar Khalid</td>
</tr>
<tr>
<td>Emerging CEO of the Year</td>
<td>Masterskill Education Group Bhd</td>
<td>Dato' Edmund Santhara</td>
</tr>
<tr>
<td>Bumiputera CEO of the Year</td>
<td>NAZA Group</td>
<td>SM Faisal SM Nasimuddin</td>
</tr>
<tr>
<td>Bumiputera Entreprenuer of the Year</td>
<td>Lembaga Tabung Haji</td>
<td>Datuk Ismee Ismail</td>
</tr>
<tr>
<td>Emerging Entreprenuer of the Year</td>
<td>Cosmopoint Sdn bhd</td>
<td>Dato' Idrus Mohd Satha</td>
</tr>
<tr>
<td>Woman Entreprenuer of the Year</td>
<td>Quill Construction Sdn Bhd</td>
<td>Dato' Jennifer Low</td>
</tr>
<tr>
<td colspan="3"><strong>Industry Excellence Awards :</strong></td>
</tr>
<tr>
<td>Automotive Sector</td>
<td>NAZA Group</td>
<td>SM Faisal SM Nasimuddin</td>
</tr>
<tr>
<td>Banking Sector</td>
<td>K&amp;N Kenanga Holding Berhad</td>
<td>Tengku Zafrul Aziz</td>
</tr>
<tr>
<td>Engineering &amp; Construction Sector</td>
<td>HSS Engineering Sdn Bhd</td>
<td>Dato' Ir Kuna Sittampalam</td>
</tr>
<tr>
<td>ICT Sector</td>
<td>Multimedia Development Corp Bhd</td>
<td>Dato' Mohd Badlisham Ghazali</td>
</tr>
<tr>
<td>Land Banking Sector</td>
<td>Walton International Group</td>
<td>Abdul Razak bin Abdul Ghani</td>
</tr>
<tr>
<td>Manufacturing Sector</td>
<td>Hextar Chemicals Sdn Bhd</td>
<td>Dato' Ong Soon Ho</td>
</tr>
<tr>
<td>Property Development Sector</td>
<td>Fadason Holdings Sdn Bhd</td>
<td>Dato' Abdul Aziz</td>
</tr>
<tr>
<td>Medical Sector</td>
<td>Institut Jantung Negara</td>
<td>Datuk Mohd Radzif Yunus</td>
</tr>
<tr>
<td>Private Education Sector</td>
<td>Binary University College Malaysia</td>
<td>Dato' Prof Joseph Adaikalam</td>
</tr>
<tr>
<td>Public Education Sector</td>
<td>Universiti Teknologi Mara</td>
<td>Tan Sri Prof Dr Ibrahim bin Abu Shah</td>
</tr>
<tr>
<td>Technology Sector</td>
<td>Fibon Berhad</td>
<td>Pang Chee Khiong</td>
</tr>
<tr>
<td>Telecommunications Sector</td>
<td>Celcom (M) Berhad</td>
<td>Dato' Sri Mohammed Shazalli Ramly</td>
</tr>
<tr>
<td>Healthcare Sector</td>
<td>SterilGamma (M) Sdn Bhd</td>
<td>En. Syed Ali Aljeffri</td>
</tr>
<tr>
<td>Retail Chain Sector</td>
<td>Bonia Corporation Berhad</td>
<td>Albert Chiang</td>
</tr>
<tr>
<td>Best Job Portal of the Year</td>
<td>Kareer.com.my (Perfisio Solution Sdn Bhd)</td>
<td>En. Fareed Abdul Ghani</td>
</tr>
</tbody>
</table>
<br/>
<h3>4th INSTALLATION</h3>
<table width="100%" class="table">
<tbody>
<tr>
<td width="30%"><strong>Category</strong></td>
<td width="35%"><strong>Company Name</strong></td>
<td width="35%"><strong>Recipient Name</strong></td>
</tr>
<tr>
<td>Posthumous Award</td>
<td colspan="2">A Tribute to Haji Abu Backer Hussain</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Felda Global Ventures Holdings Sdn Bhf</td>
<td>Tan Sri Dr Mohd Yusof Noor</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>AmBank Group</td>
<td>Tan Sri Dato' Azman Hashim</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Sin Chew Daily</td>
<td>Tan Sri Datuk Tiong Hiew King</td>
</tr>
<tr>
<td>Global CEO of the Year</td>
<td>AirAsia Berhad</td>
<td>Tan Sri Dr. Tony Fernandes</td>
</tr>
<tr>
<td>GLC CEO of the Year</td>
<td>Permodalan Nasional Berhad</td>
<td>Tan Sri Dato' Hamad Kama Piah</td>
</tr>
<tr>
<td>CEO of the Year</td>
<td>Celcom (M) Berhad</td>
<td>Dato' Sri Mohammed Shazalli Ramly</td>
</tr>
<tr>
<td>Leadership in Innovation &amp; Creativity</td>
<td>Limkokwing University of Creative Technology</td>
<td>Professor Emeritus Tan Sri Dato' Sri Dr Lim Kok Wing</td>
</tr>
<tr>
<td>Woman CEO of the Year</td>
<td>Quill Construction Sdn bhd</td>
<td>Dato' Jennifer Low</td>
</tr>
<tr>
<td>Bumiputera Entrepreneur of the Year</td>
<td>Naza Group</td>
<td>Datuk Wira SM Faisal Tan Sri SM Nasimuddin</td>
</tr>
<tr>
<td>International Entreprenuer &amp; Real Investment Sector</td>
<td>Walton International Property Group (M) Sdn Bhd</td>
<td>En. Abdul Razak Abdul Ghani</td>
</tr>
<tr>
<td>Emerging CEO of the Year</td>
<td>KLMU College</td>
<td>Dato' Idrus Mohd Satha</td>
</tr>
<tr>
<td>Woman Entreprenuer of the Year</td>
<td>Zazen Health Solution Sdn Bhd</td>
<td>Miss Yosatha Krishna</td>
</tr>
<tr>
<td>Bumiputera CEO of the Year</td>
<td>Proton Holdings Berhad</td>
<td>Dato' Sri Haji Syed Zainal Abidin</td>
</tr>
<tr>
<td>Bumiputera Women CEO of the Year</td>
<td>Plus Expressways Berhad</td>
<td>Dato' Noorizah Hj Abdul Hamid</td>
</tr>
<tr>
<td>Conglomerate Company of the Year</td>
<td>Bousted Holdings Berhad</td>
<td>Tan Sri Dato' Lodin Wok Kamaruddin</td>
</tr>
<tr>
<td>CSR Company of the Year</td>
<td>Masterskill Education Group</td>
<td>Dato' Sri Edmund Santhara</td>
</tr>
<tr>
<td>Emerging Bank of the Year</td>
<td>AgroBank Malaysia Berhad</td>
<td>Datuk Haji Ahmad Said</td>
</tr>
<tr>
<td colspan="3"><strong>Industry Excellence Awards :</strong></td>
</tr>
<tr>
<td>International Investment Sector</td>
<td>Iskandar Regional Development Authority</td>
<td>En. Ismail Ibrahim</td>
</tr>
<tr>
<td>Banking Sector</td>
<td>Bank Rakyat Berhad</td>
<td>Datuk Kamaruzaman Che Mat</td>
</tr>
<tr>
<td>Energy Sector</td>
<td>Tenaga Nasional Berhad</td>
<td>Datuk Seri Che Khalib Mohamad Noh</td>
</tr>
<tr>
<td>Property Sector</td>
<td>Bandar Raya Developments Bhd</td>
<td>Datuk Jagan Sabapathy</td>
</tr>
<tr>
<td>Retail Chains Sector</td>
<td>Mydin Mohamed Holdings Bhd</td>
<td>Dato' Hj Ameer Ali Mydin</td>
</tr>
<tr>
<td>E-Commerce Sector</td>
<td>Uptrend Network Sdn Bhd</td>
<td>Dato' Susie Yeoh</td>
</tr>
<tr>
<td>Logistic &amp; Transportation Sector</td>
<td>Poslaju (M) Sdn Bhd</td>
<td>Tuan Haji Nadza Abdul</td>
</tr>
<tr>
<td>Islamic Financial Services Sector</td>
<td>MAA Takaful Berhad</td>
<td>En. Salim Majid Zain</td>
</tr>
<tr>
<td>Manufacturing Sector</td>
<td>APM Automotive Holdings Berhad</td>
<td>Dr. Fun Who Peng</td>
</tr>
<tr>
<td>Recycling Sector</td>
<td>GMS Holdings (M) Sdn Bhd</td>
<td>Dato' Dr. C. Baskaran</td>
</tr>
<tr>
<td>Hospitality Sector</td>
<td>De Palma Group of Hotels</td>
<td>Datuk Hj Mohd Ilyas</td>
</tr>
<tr>
<td>Automotive Sector</td>
<td>Oriental Holdings Berhad</td>
<td>Dato' Robert Wong Lum Kong</td>
</tr>
<tr>
<td>FMCG Sector</td>
<td>Kumpulan Barkath Sdn Bhd</td>
<td>Dato' Haji Barkath Ali Abu Backer</td>
</tr>
<tr>
<td>ICT Sector</td>
<td>Perfisio Solution Sdn Bhd</td>
<td>En. Fareed Abdul Ghani</td>
</tr>
<tr>
<td>Health &amp; Wellness Sector</td>
<td>Clara International</td>
<td>Datin Prof Dr. Clara L Chee</td>
</tr>
<tr>
<td>Medical Sector</td>
<td>Island Hospital Sdn Bhd</td>
<td>Dato' Dr Chan Kok Ewe</td>
</tr>
<tr>
<td>Education &amp; Training (Public)</td>
<td>Universiti Tenaga Nasional</td>
<td>Prof. Dato' Dr. Mashkuri Yaacob</td>
</tr>
<tr>
<td>Education &amp; Training (Private)</td>
<td>Snips Academy &amp; Salon</td>
<td>Mr. Mike Loh</td>
</tr>
</tbody>
</table>
<br/>
<h3>3rd INSTALLATION</h3>
<table width="100%" class="table">
<tbody>
<tr>
<td width="30%"><strong>Category</strong></td>
<td width="35%"><strong>Company Name</strong></td>
<td width="&quot;35%"><strong>Recipient Name</strong></td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Berjaya Corporation Berhad</td>
<td>Tan Sri Vincent Tan Chee Yioun</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>RAM Holdings Berhad</td>
<td>Tan Sri Datuk C. Rajandram</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Nadicorp Holdings Sdn Bhd</td>
<td>Dato' Mohd Nadzmi Mohd Salleh</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Chase Perdana Sdn Bhd</td>
<td>Tan Sri Datuk Dr. Mohan M.K. Swami</td>
</tr>
<tr>
<td>Entreprenuer Of the Year</td>
<td>Hektar Group of Companies</td>
<td>Dato' Jaafar Abdul Hamid</td>
</tr>
<tr>
<td>CEO Of the Year</td>
<td>CIMB Group</td>
<td>Dato' Seri Nazir Tun Razak</td>
</tr>
<tr>
<td colspan="3"><strong>Industry Excellence Awards:</strong></td>
</tr>
<tr>
<td>Banking &amp; Finance Sector</td>
<td>Maybank Group</td>
<td>Dato' Sri Abdul Wahid Omar</td>
</tr>
<tr>
<td>Insurance Sector</td>
<td>Takaful Ikhlas Sdn Bhd</td>
<td>Dato' Hj. Syed Moheeb Syed Kamarulzaman</td>
</tr>
<tr>
<td>Logistics &amp; Transportation Sector</td>
<td>SA Kargo Sdn Bhd</td>
<td>Dato' Samsudin Abdul Rahman</td>
</tr>
<tr>
<td>Hospitality Sector</td>
<td>Triways Travel Network Sdn Bhd</td>
<td>Haji Mohd Yusof Abdul</td>
</tr>
<tr>
<td>Health Service Sector</td>
<td>Primabumi Sdn Bhd</td>
<td>Tan Sri Dato' Hj M. Ariffin Yusuf</td>
</tr>
<tr>
<td>Education Sector</td>
<td>INTI International University</td>
<td>Dr. Tan Yew Sing</td>
</tr>
<tr>
<td>Trading Sector</td>
<td>Kumpulan Rahman Brothers Sdn Bhd</td>
<td>Dato' Hj Abdul Rahman Hj Ibrahim</td>
</tr>
<tr>
<td>Food &amp; Beverage Sector</td>
<td>Restoran Sekinchan Ikan Bakar</td>
<td>Datuk Jamal Md Yunos</td>
</tr>
<tr>
<td>ICT Sector</td>
<td>Sarawak Information Systems</td>
<td>Dato' Teo Tien Hiong</td>
</tr>
<tr>
<td>Agriculture Sector</td>
<td>TH Plantation Berhad</td>
<td>Dato' Zainal Azwar Zainal Aminuddin</td>
</tr>
<tr>
<td>Manufacturing Sector</td>
<td>Meastro Laboratories Sdn Bhd</td>
<td>Mr. James Ng Chet Luk</td>
</tr>
<tr>
<td>Biotechnology Sector</td>
<td>Bioalpha International Sdn Bhd</td>
<td>Mr. William Hon Tian Kok</td>
</tr>
<tr>
<td>Asset Management Sector</td>
<td>Public Gold Group</td>
<td>Dato' Louis Ng chun Hau</td>
</tr>
<tr>
<td>Food Industries Sector</td>
<td>Dewina Holdings Sdn Bhd</td>
<td>Datuk Hj Ibrahim Hj Ahmad Badawi</td>
</tr>
<tr>
<td>Husbandry Sector</td>
<td>Amity AKF Sdn Bhd</td>
<td>Mr. Out Teck Meng</td>
</tr>
</tbody>
</table>
<br/>
<h3>2nd INSTALLATION</h3>
<table width="100%" class="table">
<tbody>
<tr>
<td width="30%"><strong>Category</strong></td>
<td width="35%"><strong>Company Name</strong></td>
<td width="&quot;35%"><strong>Recipient Name</strong></td>
</tr>
<tr>
<td>Legendary Lifetime Achievement Award</td>
<td>IGB Corporation Berhad</td>
<td>Dato' Tan Chin Nam</td>
</tr>
<tr>
<td>Lifetime achievement Award</td>
<td>National Land Finance Cooperative Society</td>
<td>Tan Sri Dato' K.R. Somasundram</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>EMKAY Group</td>
<td>Tan Sri Dato'? (Dr.) Hj. Mustapha Kamal</td>
</tr>
<tr>
<td>CEO Of the Year</td>
<td>YTL Corporation Berhad</td>
<td>Tan Sri Dato' (Dr.) Francis Yeoh Sock Ping</td>
</tr>
<tr>
<td>Entreprenuer of the Year</td>
<td>Crescent Capital Sdn Bhd</td>
<td>En. Mirzan Mahathir</td>
</tr>
<tr>
<td>Young Entrepreneur of the Year</td>
<td>Cornet Research Sdn Bhd</td>
<td>Mr. Lee Yew Chen</td>
</tr>
<tr>
<td>International Excellence Award</td>
<td>UMW Holdings Berhad</td>
<td>Dato' Syed Hisham Syed Wazir</td>
</tr>
<tr>
<td colspan="3"><strong>Industry Excellence Awards 2012 :</strong></td>
</tr>
<tr>
<td>Agriculture Sector</td>
<td>BOH Plantations Sdn Bhd</td>
<td>Ms. Caroline Russell</td>
</tr>
<tr>
<td>Asset Management Sector</td>
<td>Pelaburan Hartanah Berhad</td>
<td>Datuk Kamalul Arifin Othman</td>
</tr>
<tr>
<td>Automotive Sector</td>
<td>Perodua Berhad</td>
<td>Dato' Hj. Aminar Rashid Salleh</td>
</tr>
<tr>
<td>Development &amp; Construction Sector</td>
<td>LBI Capital Berhad</td>
<td>Dato' Ng Chin Heng</td>
</tr>
<tr>
<td>Education Sector</td>
<td>AIMST University</td>
<td>Dato' Seri (Dr.) S. Samy Vellu</td>
</tr>
<tr>
<td>Food and beverage Sector</td>
<td>Syarikat Little Caterers Sdn Bhd</td>
<td>Dato' Shanmuga Indran</td>
</tr>
<tr>
<td>Food Industries Sector</td>
<td>Baba Products (M) Sdn Bhd</td>
<td>Mr. Pagalavan C. Rangasami</td>
</tr>
<tr>
<td>Health Services Sector</td>
<td>Sime Darby Healthcare Group</td>
<td>Raja Azlan Shah Raja Azwa</td>
</tr>
<tr>
<td>Hospitality Sector</td>
<td>Concorde Hotels &amp; Resorts (M) Sdn Bhd</td>
<td>Tan Sri Syed Yusof Tun Syed Nasir</td>
</tr>
<tr>
<td>ICT Sector</td>
<td>Mesinniaga Berhad</td>
<td>En. Fathil Ismail</td>
</tr>
<tr>
<td>Logistics &amp; Trasportation Sector</td>
<td>DHL Express (M) Sdn Bhd</td>
<td>Mr. David Ng</td>
</tr>
<tr>
<td>Manufacturing Sector</td>
<td>Top Glove Corporation Berhad</td>
<td>Tan Sri Dato' Lim Wee Chai</td>
</tr>
<tr>
<td>Media Sector</td>
<td>Nyanyang Siang Pau Sdn Bhd</td>
<td>Mr. Liew Sam Ngan</td>
</tr>
<tr>
<td>Oil &amp; Gas Sector</td>
<td>SapuraKencana Petroleum Berhad</td>
<td>Dato' Sri Shahril Shamsuddin</td>
</tr>
<tr>
<td>Properties Sector</td>
<td>Glomac Berhad</td>
<td>Datuk Seri Fateh Iskandar</td>
</tr>
<tr>
<td>REIT Sector</td>
<td>Pavillion REIT Management</td>
<td>Datuk Desmond Lim Siew Choon</td>
</tr>
<tr>
<td>Sports Industry Sector</td>
<td>Al-Ikhsan Sports Sdn Bhd</td>
<td>En. Ali Hasan Mohd Hassan</td>
</tr>
</tbody>
</table>
<br/>
<h3>1st INSTALLATION</h3>
<table width="100%" class="table">
<tbody>
<tr>
<td width="30%"><strong>Category</strong></td>
<td width="35%"><strong>Company Name</strong></td>
<td width="&quot;35%"><strong>Recipient Name</strong></td>
</tr>
<tr>
<td>Legendary Lifetime Achievement Award</td>
<td>YTL Corporation</td>
<td>Tan Sri Dato' Seri (Dr) Yeoh Tiong Lay</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Inch Kenneth Kajang Rubber Plc</td>
<td>Dato' Muhamad Fasri Samsudin</td>
</tr>
<tr>
<td>Lifetime Achievement Award</td>
<td>Malaysia Airports Holdings Berhad</td>
<td>Tan Sri Bashir Ahmad bin Abdul Majid</td>
</tr>
<tr>
<td>International Excellence Award</td>
<td>Limkokwing University of Creative Technology</td>
<td>Professor Emeritus Tan Sri Dato' Sri Dr Lim Kok Wing</td>
</tr>
<tr>
<td>Conglomerate &amp; CEO of the Year</td>
<td>Axiata Group Berhad</td>
<td>Dato' Sri Jamaludin Ibrahim</td>
</tr>
<tr>
<td>Young Entreprenuer of the Year</td>
<td>AUM Hospitality Sdn Bhd</td>
<td>Ashwin Prakash</td>
</tr>
<tr>
<td>Conglomerate of the year</td>
<td>YTL Corperation</td>
<td>Tan Sri Dato' (Dr.) Francis Yeoh Sock Ping</td>
</tr>
<tr>
<td>CEO of the Year</td>
<td>QI Group of Companies</td>
<td>Dato' Sri Dr. Vijay Eswaran</td>
</tr>
<tr>
<td>Entreprenuer of the Year</td>
<td>Proven Group of Companies</td>
<td>Dato' Dr. Yusof Jusoh</td>
</tr>
<tr>
<td>Young Entreprenuer of the Year</td>
<td>Food Artists (M) Sdn Bhd</td>
<td>Mohamad Sabrie Salleh</td>
</tr>
<tr>
<td>Young Woman Entrepreneur of the Year</td>
<td>Limkokwing Fashion Club</td>
<td>Dato' Tiffanee Marie Lim</td>
</tr>
<tr>
<td colspan="3"><strong>Industry Excellence Awards -</strong></td>
</tr>
<tr>
<td>Agriculture Sector</td>
<td>Sarawak Plantations Berhad</td>
<td>Datuk Haji Hamden Ahmad</td>
</tr>
<tr>
<td>Asset Management Sector</td>
<td>Iskandar Investment Berhad</td>
<td>Datuk Syed Mohamed bin Syed Ibrahim</td>
</tr>
<tr>
<td>Automotive Sector</td>
<td>UMW Toyota Motor Sdn Bhd</td>
<td>Datuk Ismet Suki</td>
</tr>
<tr>
<td>Banking &amp; Finance Sector</td>
<td>RHB Capital Berhad</td>
<td>Kellee Kam Chee Khiong</td>
</tr>
<tr>
<td>Biotech Sector</td>
<td>Bioalpha International Sdn Bhd</td>
<td>William Hon Tian Kok</td>
</tr>
<tr>
<td>Courier Services Sector</td>
<td>ABX Express (M) Sdn Bhd</td>
<td>Ali bin Noordin</td>
</tr>
<tr>
<td>Development &amp; Construction Sector</td>
<td>Malaysia Resources Corporation Berhad</td>
<td>Datuk Salim Fateh Din</td>
</tr>
<tr>
<td>Education Sector</td>
<td>SEGI University</td>
<td>Tan Sri Clement Hii Chii Kok</td>
</tr>
<tr>
<td>Food Industries Sector</td>
<td>Perfect Food Manufacturing (M) Sdn BHd</td>
<td>Martin Ang Mui Chin</td>
</tr>
<tr>
<td>Food &amp; Beverage Sector</td>
<td>Madam Kwan's</td>
<td>Datin Maureen Ooi Mei Yoong</td>
</tr>
<tr>
<td>Fashion Retail Sector</td>
<td>PU3</td>
<td>Putri Yasmin Ashram Ramli &amp;<br>
Putri Azalea Ashram Ramli</td>
</tr>
<tr>
<td>Healthcare Sector</td>
<td>Pharmaniaga Berhad</td>
<td>Dato' Farshila Emran</td>
</tr>
<tr>
<td>ICT Sector</td>
<td>Fireworks Solutions Sdn Bhd</td>
<td>Yanzer Lee Tseng Yip</td>
</tr>
<tr>
<td>Logistics &amp; Transportation Sector</td>
<td>Malaysia Airline System Berhad</td>
<td>Ahmad Jauhari Yahya</td>
</tr>
<tr>
<td>Oil &amp; Gas Sector</td>
<td>TH Heavy Engineering Berhad</td>
<td>Nor Badli Mohd Alias LAfti</td>
</tr>
<tr>
<td>Professional Services Sector</td>
<td>Juteras Sdn Bhd</td>
<td>Khoo Boo Siew</td>
</tr>
<tr>
<td>Properties Sector</td>
<td>Glomac Berhad</td>
<td>Dato' FD Iskandar Mansor</td>
</tr>
<tr>
<td>Retail Management Sector</td>
<td>Tetap Tiara Sdn Bhd (Jaya One)</td>
<td>Charles Wong Wai Hon</td>
</tr>
<tr>
<td>Retail Sector</td>
<td>Tomei Consolidated Group</td>
<td>Dato' Ng Yih Pying</td>
</tr>
<tr>
<td>Trading Sector</td>
<td>Jakel Trading</td>
<td>Datuk Hj Mohamed Faroz Mohamed Jakel</td>
</tr>
</tbody>
</table>







</div>
</div>







</div>
</div>
</div>
<?php include "footer.php"; ?>