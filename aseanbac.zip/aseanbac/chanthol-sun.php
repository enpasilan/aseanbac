<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Chanthol SUN</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Chanthol SUN" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Chanthol SUN</strong>
					<br>
					Senior Minister, Minister of Commerce and Vice Chairman of the Council for the Development of Cambodia (CDC).
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Chanthol Sun is currently a Senior Minister, Minister of Commerce and Vice Chairman of the Council for the Development of Cambodia (CDC). He was previously a Senior Minister and Vice Chairman of the CDC from 2008 to 2013. Mr. Sun was a Minister of Public Works and Transport from 2004 to 2008 and was elected as a Member of Parliament in 2003. He founded SCI Co., Ltd., an investment and trading firm, in Cambodia in 1999, and served as an Economic and Finance Advisor to the President of the National Assembly from 1999 to 2003. Mr. Sun was a Secretary of State for the Ministry of Economy and Finance and Secretary General of the CDC from 1994 to 1997.</p>
			<p>Previously, Mr. Sun worked for General Electric for 16 years where he held a variety of executive positions. He received a B.S. in Business Administration (BSBA) from American University, Advanced Management Program (AMP) from the Wharton School, University of Pennsylvania, and a Master in Public Administration (MPA) from Harvard University.</p>
			<p>Mr. Sun was elected as a Global Leader for Tomorrow of the World Economic Forum in 1995. He has been a member of the Wharton Executive Board for Asia since 2002 and served as the first Chairman of the Wharton Executive Board for Asia from 2009 to 2013.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>