<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Dr. Lim Hong Hin</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Lim Hong Hin" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Dr. Lim Hong Hin</strong>
					<br>
					Deputy Secretary-General of ASEAN
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Dr. Lim Hong Hin was first appointed by the ASEAN Coordinating Council as the Deputy Secretary-General of ASEAN for the ASEAN Economic Community for the period of 2012 to 2015 to support ASEAN Member States' effort to transform ASEAN into a region with free movement of goods, services, investment, skilled labour, and freer flow of capital. He was reappointed for another term till the end of December 2017.</p>
			<p>He had previously served at the Brunei Economic Development Board, Prime Minister's Office where he was responsible for attracting, retaining and adding value to foreign direct investment to diversify Brunei Darussalam's economy to create new opportunities for SMEs and local people.</p>
			<p>In his earlier stint at the ASEAN Secretariat, he was responsible to oversee the implementation of the ASEAN Free Trade Agreement and ASEAN Framework Agreement on Services. He was responsible for exploring ways to further enhance economic relations between ASEAN and its trading partners including Australia, China, European Union, Japan, South Korea, New Zealand and the United States. He was responsible for fostering common positions on issue of interests to ASEAN at international fora including APEC and WTO.</p>
			<p>He started his career with the Economic Planning Unit, Prime Minister's Office of Brunei Darussalam and the Ministry of Finance of Brunei Darussalam to oversee the implementation of management information system for several government ministries and agencies.</p>
			<p>He reads business administration, cybernetics, information technology and management from University of Reading, University of Hull, University of Western Australia and The London School of Economics and Political Science.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>