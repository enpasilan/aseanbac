<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>

            <div class="row">
            	<div class="span12">
                	
                    <h1><strong>Apply for ABAM 2016</strong></h1>

<p>
<strong>The completed application form and other materials (if any) must be received by the following addresses latest by 4th May 2016:</strong>
</p>
<p>ASEAN-BAC Malaysia Secretariat</p>
<p>
9-1, 9th floor, West Wing, Menara MATRADE, <br/>
Jalan Sultan Haji Ahmad Shah, 50480 Kuala Lumpur. 
</p>
     <p>
Tel: + 603-6211 2511 <br/>
Fax: + 603-6211 4533 <br/>
Email: secretariat@aseanbex.com and azilla@aseanbex.com 

</p> 
<br/>              
<p>
<a class="btn text-uppercase" target="_blank" href="http://aseanbac.com.my/_content/abam2016/application_form_extended_version.pdf" onclick="ga('send', 'event', 'PDF Download', 'click', 'Application Form - PDF Download', '4');">Download Application Form here</a>
</p>               
                    
                </div>
               
            </div><!-- end .row -->
            
		</div><!-- end #content -->
<?php include "footer.php"; ?>