<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>PROEIGHT</h2>
              <div class="post-2191 page type-page status-publish hentry text-edit">
            
<p>PROEIGHT, an American Petroleum Institute (API) Q1 Certified Company, is geared to provide Total Engineering Solution for Mechanical Seals, Pumps and Sealing Systems across the world.</p>
<p>ProEight possesses a strong track record in Mechanical Seals� Product Design and Product Refurbishment. ProEight offers its products and services to the industrial endusers based on its passion for technology, and its great understanding in product applications, all catering to the demand for the highest quality of product and services.</p>
<p>ProEight also provides engineering consultation, specializing in Marine Engineering studies, installation of offshore structures, launching and upending of jackets and the engineering<br>
studies on the feasibilities of installation of pipeline and risers. ProEight works hand-in-hand with Engineering, Procurement, Construction, Installation and Commissioning (EPCIC) contractors in providing consultation for Marine Engineering and Installation of Offshore Structures.</p>
<p>Research and Development (R&amp;D) serves to bolster its competencies by offering expertise and services to the world. ProEight has become a leading, innovative provider to industries, fulfilling the roles of specialist, solving the end-users� engineering problems via inventive and innovative approaches.</p>
<p>ProEight also recognises its role in the distribution chain and in society as a whole. Present-day views on Sustainability and Corporate Social Responsibility (CSR) are anchored in ProEight�s<br>
strategy and operational management. ProEight defines its corporate strategy that shapes with values to be practiced each day by its employees as they engage with society.</p>
<p>Fuelled by the outlook towards globalisation, ProEight sits proudly at the forefront among engineering conglomerates. With a presence in Houston, Philippines, Saudi Arabia, Thailand and Malaysia, ProEight is committed to providing the highest quality of Mechanical Seals, Pumps and Sealing Systems to the world. </p>
 

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>