<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>VITROX</h2>
              <div class="post-2195 page type-page status-publish hentry text-edit">
            
<p>VITROX designs and manufactures innovative, leading-edge and cost-effective automated vision inspection equipment and system-on-chip embedded electronics devices for the semiconductor and electronics packaging industries.</p>
<p>It is the first Company offering inspection solution from Electronics Component Level to Board Level.</p>
<p>ViTrox�s core products are Machine Vision System (MVS), Automated Board Inspection (ABI) and Electronics Communication System (ECS). It serves customers from semiconductor Outsourced Assembly and Test (OSAT) companies, printed circuit board manufacturers, electronics assemblies companies, Original Equipment Manufacturers (OEM), Original Design Manufacturers (ODM), Electronics Manufacturing Services (EMS) providers and Contract Manufacturers (CM) around the world.</p>
<p>ViTrox�s products are adopted by major Tier-1 &amp; Tier- 2 Original Equipment Manufacturers (OEM) and<br>
Contract Manufacturers (CM) worldwide. </p>
<p>The Company ships more than 70% of the products overseas covering China, Taiwan, Philippines, Thailand, Korea, Japan, India, US, Mexico, Brazil, Hungary, Romania, Slovakia and UK.</p>
<p>Besides that, ViTrox has won numerous awards and recognition locally and internationally since its inception, ranging from product development, corporate performance, human development as well as personal awards.</p>
 
          </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>