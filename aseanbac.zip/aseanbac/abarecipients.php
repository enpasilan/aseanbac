<?php include "header.php"; ?>
<div id="content">
	<br/><br/>

	<div class="row">
		<div class="span12">
		<br/>
			<h1>ABA 2015 Recipients</h1><br>
<table class="table" width="996">
<tbody>
<tr>
<td width="246"><strong>ABA Awards</strong></td>
<td width="132"><strong>Winners (company)</strong></td>
<td width="186"><strong>Winners (individual)</strong></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Agro-based</td>
<td><a href="sl-agritech-corporation.php">SL Agritech Corporation</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Automotive</td>
<td><a href="drb-hicom.php">DRB-Hicom Berhad</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Aviation</td>
<td><a href="airasia.php">AirAsia Berhad</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - E-ASEAN</td>
<td><a href="mit.php">Myanmar Information Technology Pte. Ltd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Electronics</td>
<td><a href="g-gear.php">G Gear Co., Ltd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Fisheries</td>
<td><a href="ql-resources.php">QL Resources Berhad</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Healthcare</td>
<td><a href="health-management-international.php">Health Management International Limited</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Logistics</td>
<td><a href="lbc-express.php">LBC Express, Inc.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Rubber-based</td>
<td><a href="kossan-rubber-industries.php">Kossan Rubber Industries Bhd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Textiles</td>
<td><a href="color-silk.php">Color Silk Co., Ltd</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Tourism</td>
<td><a href="myanmar-voyages.php">Myanmar Voyages International Tourism Co.,Ltd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award - Wood-based</td>
<td><a href="pointray.php">Pointray (Malaysia) Sdn. Bhd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: SME Excellence Award - Employment</td>
<td><a href="proeight.php">ProEight Sdn. Bhd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: SME Excellence Award - Innovation</td>
<td><a href="vitrox.php">ViTrox Technologies Sdn. Bhd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: SME Excellence Award - Corporate Social Responsibilities</td>
<td><a href="vg-offshore-containers-international.php">VG Offshore Containers International (M) Sdn. Bhd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: SME Excellence Award - Growth</td>
<td><a href="wise-concetti-limited.php">Wise Concetti Ltd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: Young Entrepreneur of the Year Award</td>
<td>Myanma Awba Group</td>
<td><a href="u-thadoe-hein.php">Thadoe Hein</a></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: Woman Entrepreneur of the Year Award</td>
<td>Kanbawza Bank Ltd.</td>
<td><a href="daw-nan-than-htwe.php">Daw Nan Than Htwe</a></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: Friends of ASEAN Award</td>
<td><a href="robert-bosch-sea-pte-ltd.php">Robert Bosch (SEA) Pte. Ltd.</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: Friends of ASEAN Award</td>
<td><a href="prudential-corporation-asia.php">Prudential Corporation Asia</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: Friends of ASEAN Award</td>
<td><a href="michelin.php">Michelin</a></td>
<td></td>
</tr>
<tr>
<td>ASEAN Business Awards 2015: ASEAN-BAC ASEAN Lifetime Achievement Award</td>
<td></td>
<td><a href="tan-sri-rafidah-aziz.php">Y. Bhg Tan Sri Rafidah Aziz</a></td>
</tr>
</tbody>
</table>
<br/>

<h1>ASEAN Business Awards - Past Winners</h1><br>

<table class="table" width="996">
<tbody>
<tr>
<td width="246"><strong>Category</strong></td>
<td width="132"><strong>Criteria</strong></td>
<td width="186"><strong>Winner/Runner-Up</strong></td>
<td width="354"><strong>Company</strong></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132"></td>
<td width="186">Winner</td>
<td width="354">Singtel</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132"></td>
<td width="186">Winner</td>
<td width="354">CapitaLand</td>
</tr>
<tr>
<td width="246">Innovation</td>
<td width="132"></td>
<td width="186">Winner</td>
<td width="354">Zest-O Corporation</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132"></td>
<td width="186">Winner</td>
<td width="354">PT. Kalbe Farma Tbk</td>
</tr>
<tr>
<td colspan="4" width="996"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Alliance Global Group Inc.</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Keppel Offshore &amp; Marine Limited (Keppel O&amp;M)</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Martha Tilaar Group</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">The Bangchak Petroleum Public Company Limited</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Cherie Hearts Group International Pte. Ltd.</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Network Express Courier Services Pte Ltd.</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Pewter Art</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">The Wongpanit Garbage Recycle Separation Plant</td>
</tr>
<tr>
<td colspan="4" width="996"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Top Glove Corporation Berhad</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Tenaga Nasional Berhad</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">YCH Group Pte Ltd</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Keppel Land Limited</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Thu Duc Housing Development Corporation</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">KPJ Ampang Puteri Specialist Hospital</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">SeaBank</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Greenpac Pte Ltd</td>
</tr>
<tr>
<td colspan="4" width="996"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Charoen Pokphand Foods Public Co. Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner-Up</td>
<td width="354">PT. Bank Tabungan Pensiunan Nasional Tbk</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">CIMB Group Holdings</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner-Up</td>
<td width="354">PT. Bank Negara Indonesia Tbk</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">PT. Kalbe Farma Tbk</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner-Up</td>
<td width="354">Delta Electronics (Thai) Public Co. Limited</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">City Development Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner-Up</td>
<td width="354">Mitr Phol Dugar Corp. Limited</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">CV. Media Kreasi Bangsa</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner-Up</td>
<td width="354">Feinmetall Singapore</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">PT. Sarandi Karya Nugraha</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner-Up</td>
<td width="354">Achieve Group</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Rigel Technology Pte. Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner-Up</td>
<td width="354">PT. Jaty Arthamas</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Meritus Hotels &amp; Resorts</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner-Up</td>
<td width="354">Thumbprints Utd. Sdn. Bhd</td>
</tr>
<tr>
<td colspan="4" width="996"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Falcon Incorporation Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">ACLEDA Bank Plc</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Meritus Hotels &amp; Resorts</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PT Bank Negara Indonesia (Persero) Tbk</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">EEI Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">ACLEDA Bank Plc</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PT Kalbe Farma Tbk</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Jollibee Foods Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Meritus Hotels &amp; Resorts</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PT Bank Negara Indonesia (Persero) Tbk</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Top Glove Corporation Berhad</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">CapitaLand Limited</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">First Finance Plc</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Agrotech Vita Co., Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Lao Indochina Group Public</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Natural Health Farm Marketing SDN BHD</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">PT ESTETIKA SELARAS</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Feinmetall Singapore Pte Ltd</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Rigel Technology(s) Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Malaysia Microelectronic Solution Sdn Bhd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">PT Anugraha Wening</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">EPI Mobile Health Solutions Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">PT MagFood Inovasi Pangan</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Saigon Paper Joint Stock Company</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Siloso Beach Resort</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Adrenalin Events and Education Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132"></td>
<td width="186"></td>
<td width="354"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">OKH Global Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PetroVietnam Drilling &amp; Well Services Corp</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Serrano Holdings Pte Ltd</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Keppel Land Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Charoen Pokphand Foods Public Company Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Astro Malaysia Holdings Berhad</td>
</tr>
<tr>
<td width="246">Innovation</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Delta Electronics (Thailand) Public Company Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PT Dasa Windu Agung</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">DBS Bank</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">DBS Bank</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">BMC Food Industries Sdn Bhd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">EON The Stakeholder Relations Firm</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Batamindo Shipping &amp; Warehousing Pte Ltd</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Magsaysay Maritime Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">BMC Food Industries Sdn Bhd</td>
</tr>
<tr>
<td width="246">Innovation</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Rigel Technology(s) Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Biomax Tecnologies Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Alleira Batik</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Natural Health Farm Marketing Sdn Bhd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Megamas Training Company Sdn Bhd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">EON The Stakeholder Relations Firm</td>
</tr>
<tr>
<td width="246"></td>
<td width="132"></td>
<td width="186"></td>
<td width="354"></td>
</tr>
<tr>
<td width="246">ASEAN Centricity</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">UOB (United Overseas Bank)</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner Up</td>
<td width="354">Golden ABC, Inc</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Third</td>
<td width="354">Myanmar Airways International</td>
</tr>
<tr>
<td width="246">Corporate Excellence</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Keppel Land International Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner Up</td>
<td width="354">International Container Terminal Services, Inc.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Third</td>
<td width="354">Kanbawza Bank Limited</td>
</tr>
<tr>
<td width="246">Innovation</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Cyclet Electrical Engineering Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner Up</td>
<td width="354">Pointwest Technologies Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Third</td>
<td width="354">FAME Pharmaceuticals Industry Co., Ltd.</td>
</tr>
<tr>
<td width="246">Small &amp; Medium Enterprise</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Absolute Kinetics Consultancy Pte Ltd.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner Up</td>
<td width="354">Kelvin Chia Yangon Ltd.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Third</td>
<td width="354">VP Bank Securities Ltd.</td>
</tr>
<tr>
<td width="246">Women Leader</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Community Health Education Emergency Rescue Services (CHEERS)Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner Up</td>
<td width="354">City Mart Holding Co., Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner Up</td>
<td width="354">Southeast Asia Commercial Joint Stock Bank (SeABank)</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Third</td>
<td width="354">Surecatch World PTE</td>
</tr>
<tr>
<td width="246">Young Entrepreneur</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Blue Ocean Operating Management Co., Ltd.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner Up</td>
<td width="354">Vintel Logistics Inc.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Third</td>
<td width="354">Nghia Nippers Corporation</td>
</tr>
</tbody>
</table>

		</div>
	</div>
</div>
<?php include "footer.php"; ?>