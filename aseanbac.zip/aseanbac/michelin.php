<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>MICHELIN</h2>
<div class="post-2239 page type-page status-publish hentry text-edit">
            
<p>MICHELIN, the leading tyre company, is dedicated to sustainably improving the mobility of goods and people by manufacturing and marketing tyres for every type of vehicle, including airplanes, automobiles, bicycles/ motorcycles, earthmovers, farm equipment and trucks. It also offers electronic mobility support services on ViaMichelin.com and publishes travel guides, hotel and restaurant guides, maps and road atlases.</p>
<p>Headquartered in Clermont-Ferrand, France, Michelin is present in more than 170 countries, has 112,300 employees and operates 68 production plants in 17 different countries. The Group has a Technology Center in charge of research, development and process engineering, with operations in Europe, North America and Asia.</p>
<p>Via its Product Lines, Michelin delivers effective solutions in response to widely varying expectations and usage patterns, depending on the country or region, has positioned the Group at the forefront of every one of these segments.</p>
<p>Bold advances in technology are the key to Michelin�s success and the company intends to remain the most innovative company in its sector. The goal is to innovate better and faster so that it maintains its lead over the competition and delivers solutions that are increasingly effective and competitive, and perfectly suited to the challenges of mobility.</p>
<p>Michelin�s chosen mission is to contribute to progress in mobility. It has opted to do this through innovation and quality, grounding its development in the core values of respect for customers, people, shareholders and the environment.</p>
 
          </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>