<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Dr. Surin Pitsuwan</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Dr. Surin Pitsuwan" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Dr. Surin Pitsuwan</strong>
					<br>
					Secretary-General of ASEAN
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Dr. Surin Pitsuwan, born on 28 October 1949, is a native of Nakorn Sri Thammarat, Southern Thailand. He received his primary and secondary education in his home province.</p>
			<p>He was awarded the American Field Service (AFS) exchange scholarship and was a high school exchange student in Minnesota, USA, in 1967-1968. He returned to Bangkok, Thailand and attended Thammasat University for two years before winning a scholarship from Claremont Men's College, Claremont, California, to complete his B.A. in Political Science (cum laude) in 1972. He then went on to Harvard University, Cambridge, Massachusetts, U.S.A., where he received his M.A. and Ph.D. in 1974 and 1982 respectively, in the field of Political Science and Middle Eastern Studies.</p>
			<p>His entire Harvard career was supported by the Winston S. Churchill Association and Rockefeller Foundation Fellowships. He also spent a year and a half studying Arabic and conducting his research at the American University in Cairo, 1975-1977, while concurrently a fellow at the Higher Institute of Islamic Research, Cairo, Egypt. He worked as a columnist for the Nation and the Bangkok Post, the two leading English daily newspapers in Bangkok, from 1975-1992.</p>
			<p>Dr. Surin taught at the Faculty of Political Science at Thammasat University from 1978-1983 and 1984-1986. He also served as an assistant to the Deputy Dean for Academic Affairs during the same period.</p>
			<p>Dr. Surin joined the American Political Science Association's Congressional Fellowship Program in 1983-1984, when he interned in the Congressional Office of US Representative Geraldine A. Ferraro (D-New York), who later became the Vice Presidential Candidate for the Democrat Party in 1984, and worked for the Senate Republican Conference in the later half of 1984. He taught Southeast Asian Affairs at the American University in Washington, D.C. during that same year.</p>
			<p>He returned to Thailand in 1984 to his teaching position at Thammasat and ran for a Parliamentary seat from Nakorn Sri Thammarat, his home town. He has been returned to Parliament eight times since 1986. As an MP, he was appointed Secretary to the Speaker of the House of Representatives (Chuan Leekpai), Secretary to Deputy Minister of Interior, Deputy Minister for Foreign Affairs during 1992-1995 and Minister of Foreign Affairs from 1997 to 2001. He served as Chair of the ASEAN Ministerial Meeting and the Chair of the ASEAN Regional Forum (ARF) in 1999-2000. In September 1999, while the ASEAN Chair, he led the efforts to get Southeast Asian governments to help restore law and order and that joint undertaking, with the support of the United Nations and the international community, brought about peace and security in East Timor.</p>
			<p>Upon leaving the foreign affairs portfolio in mid-2001, Dr. Surin was appointed a member of the Commission on Human Security of the United Nations until 2003. He also served as an advisor to the International Commission on Intervention and State Sovereignty from 1999-2001. In 2002, he concurrently served on the ILO's World Commission on the Social Dimension of Globalization until 2004. He is currently on the Advisory Board of the UN Human Security Trust Fund; the Advisory Board of the International Crisis Group (ICG); a member of the International Advisory Board of the Council on Foreign Relations in New York; an International Academic Advisor of the Centre for Islamic Studies, Oxford University; and an advisor to the Leaders Project, a conference arm of the Cohen Group of former US Secretary of Defense William S. Cohen Washington, D.C. Between 20022004, Dr. Surin was also a member of the "Wise Men Group" under the auspices of the Henri Dunant Centre for Humanitarian Dialogue (HDC) in Geneva, advising the peace negotiations between the Acehnese Independence Movement (GAM) and the Government of the Republic of Indonesia. He has just completed his assignments as a member of the Islamic Development Bank's 1440 A.H. (2020) Vision Commission under the leadership of Tun Dr. Muhammad Mahathir, former Prime Minister of Malaysia, in June 2005.</p>
			<p>Dr. Surin was a Deputy Leader of the Democrat Party, Thailand. He also served on the National Reconciliation Commission (NRC), charged with bringing peace and security back to Thailand's deep South. He also served as MP in the National Legislative Assembly (NLA). He was nominated by the Royal Thai Government and endorsed by ASEAN Leaders to be ASEAN Secretary-General for year 2008-2012.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>