<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<p>
				<a href="http://www.albukharyfoundation.org/" target="_blank"><img class="responsive-img rounded image-center" src="_layout/images/bg-body20.png" alt="yayasan-albukhary-foundation-logo"></a>
			</p><br/>
			<p><strong>MESSAGE FROM COO<br/>DR SHAMSIAH ABDUL KARIM<br/>CHIEF OPERATING OFFICER OF ALBUKHARY FOUNDATION</strong></p>
			<p>An economy will thrive when conditions are conducive for the functioning of a thriving business environment in which entrepreneurial development and a concomitant pro-business policy are given due emphasis.</p>
			<p>Investments, on the other hand, are the catalyst that will accelerate further the economy into a speedier mode as a well-functioning business metropolis. It doesn't matter whether these investments are in the form of investing in one's own economy or carving out a market niche in the other economies out there in order to spread our wings. Both will greatly assist an economy to develop, grow and prosper. It is in this sense that investment is crucial in an economy because it is essentially one of the important drivers of economic growth of a country.</p>
			<p>The return from investments, in turn, will boost profits. Some portions will be retained for further investments while a good portion can be channelled back to societies in the form of corporate social responsibility (CSR). The CSR effort will in turn makes a difference to members of the society in terms of uplifting their educational, social and economic profiles. It is with this in mind that The Albukhary Foundation has crafted its vision as <i>Making a Difference.</i></p>
			<p>But for investment to play its proper and rightful role as a driver of an economic growth of a nation, a stable and peaceful environment is a necessary and important prerequisite. We are blessed by the Almighty Allah SWT in this regard for giving us a stable and peaceful environment all this while that has enabled us to prosper as a nation.</p>
			<p>I pray to the Almighty Allah that He will continue to give us peace, stability and prosperity for our beloved Malaysia, in shaa Allah.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>