<?php
$title = array(
    'aboutabis' => 'About ABIS',
    'abisprogramme' => 'ABIS Programme',
    'speakers' => 'Speakers',
    'presentation-speeches' => 'Presentation-speeches',
    'videos' => 'Videos',
    'doodles' => 'Doodles',
    'sponsor-partners' => 'Sponser-Partners',
    'aboutaba' => 'About ABA',
    'aba-programme' => 'ABA Programme',
    'aba-recipients' => 'ABA Recipients',
    'past-aba-recipients' => 'Past ABA Recipients',
    'chairman-handover-gala-dinner' => 'About ASEAN-BAC 2015 Chairmanship Handover Gala Dinner',
    'abam-conference-on' => 'About ASEAN-BAC Malaysia 2015 Conference on: SMEs and the AEC',
    'dato-seri-najib-tun-abdul-razak' => 'Dato\' Seri Najib Tun Abdul Razak',
    'tan-sri-dr-mohd-munir-majid' => 'Tan Sri Dr Mohd Munir Majid',
    'chanthol-sun' => 'Chanthol SUN',
    'lim-hong-hin' => 'Dr. Lim Hong Hin',
    'james-zhan' => 'Dr. James Zhan',
    'paul-mandl' => 'Mr Paul Mandl',
    'gita-irawan-wirjawan' => 'Gita Irawan Wirjawan',
    'tan-sri-rastam-mohd-isa' => 'Tan Sri Rastam Mohd Isa',
    'prof-hidetoshi-nishimura' => 'Prof. Hidetoshi Nishimura',
    'yumiko-murakami' => 'Yumiko Murakami',
    'khine-thit-lwin' => 'Khine Thit Lwin',
    'violet-lim' => 'Violet Lim',
    'syed-nabil-aljeffri' => 'Syed Nabil Aljeffri',
    'dr-surin-pitsuwan' => 'Dr. Surin Pitsuwan',
    'silverlake-axis' => 'Silverlake Axis',
    'uem-group-berhad' => 'UEM Group Berhad',
    'yayasan-albukhary-foundation' => 'Yayasan AlBukhary Foundation',
    'tan-sri-rafidah-aziz' => 'TAN SRI RAFIDAH AZIZ',
);

$current_url = $_SERVER['REQUEST_URI'];
$current_page_php = end((explode('/', $current_url)));
$current_page_php = explode('.', $current_page_php);
$current_page = reset($current_page_php);

if($current_page == 'recipients_details'){
	$title_path = $main_dir.$name.'/page_title.txt';
	$this_page = file_get_contents($title_path);
}else{
	$this_page = $title[$current_page];
}
?>
<!DOCTYPE html>
<html>
	<head>

		
                
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/> 
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1,requiresActiveX=true">


		<title> <?php echo $this_page; ?> : ASEAN Business Advisory Council Malaysia Chapter</title>
		<meta name="description" content="Get in contact with ASEAN-BAC Malaysia">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

		<!-- /// Favicons ////////  -->
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="apple-touch-icon-144-precomposed.png">
		<link rel="shortcut icon" href="favicon.png">


		<!-- /// Google Fonts ////////  -->
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300italic,400italic,700,700italic">
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:400,300,300italic,400italic,700,700italic">

		<!-- /// FontAwesome Icons 4.1.0 ////////  -->
		<link rel="stylesheet" href="_layout/css/fontawesome/font-awesome.min.css">

		<!-- /// Custom Icon Font ////////  -->
		<link rel="stylesheet" href="_layout/css/iconfontcustom/icon-font-custom.css">  

		<!-- /// Template CSS ////////  -->
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/css/base.css">
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/css/grid.css">
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/css/layout.css">
		<link rel="stylesheet" href="_layout/css/elements.css">
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/css/skins/red.css"> 
		<!-- /// Boxed layout ////////  -->
		<!-- <link rel="stylesheet" href="http://aseanbac.com.my/_layout/css/boxed.css"> -->

		<!-- /// JS Plugins CSS ////////  -->
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/js/revolutionslider/css/settings.css">
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/js/revolutionslider/css/custom.css">
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/js/bxslider/jquery.bxslider.css">
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/js/magnificpopup/magnific-popup.css">
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/js/animations/animate.min.css">
		<link rel="stylesheet" href="http://aseanbac.com.my/_layout/js/itplayer/css/YTPlayer.css">




	</head>
	<body>


		<div id="wrap">    	        

			<div id="header">

				<!-- /// HEADER  //////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

				<div id="header-top">	

					<!-- /// HEADER TOP   /////////////////////////////////////////////////////////////////////////////////////////////////// -->

					<div class="row">
						<div class="span3">

							<!-- // Logo // -->
							<a href="index.html" id="logo">
								<img class="responsive-img" src="_layout/images/logo.png" alt="">
							</a>

						</div><!-- end .span3 -->
						<div class="span6" id="header-top-widget-area-1">
							<!--     <h3 class="widget-title">Connect with us socialy!</h3>
							      
				   
							      <a class="googleplus-icon social-icon" href="#">
								  <i class="fa fa-google-plus"></i>
							      </a>
							      
							      <a class="twitter-icon social-icon" href="#">
								  <i class="fa fa-twitter"></i>
							      </a>
							      
							      <a class="facebook-icon social-icon" href="#">
								  <i class="fa fa-facebook"></i>
							      </a> end .ewf_widget_social_media -->
							<div class="widget ewf_widget_social_media">



							</div> 

						</div><!-- end .span6 -->
						<div class="span3" id="header-top-widget-area-2">

							<div class="widget widget_search">

								<form action="#" class="searchform" id="searchform" method="get" name="searchform">
									<div>
										<label class="screen-reader-text" for="s">Search for:</label> 
										<input id="s" name="s" type="text" placeholder="enter keyword here"> 
										<input id="searchsubmit" type="submit" value="">
									</div>
								</form>

							</div><!-- end .widget_search -->

						</div><!-- end .span3 -->
					</div><!-- end .row -->	

					<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->    

				</div><!-- end #header-top -->

				<div class="row">
					<div class="span2" id="header-widget-area-1">

						<div class="widget ewf_widget_contact_info">

							<ul>
								<li>

								</li>
								<li>

								</li>
							</ul>

						</div><!-- end .ewf_widget_contact_info -->

					</div><!-- end .span4 -->
					<div class="span10">

						<a href="#" id="mobile-menu-trigger">
							<i class="fa fa-bars"></i>
						</a>

						<!-- // Menu // -->
														<ul class="sf-menu fixed" id="menu">
						<li class="current dropdown">
                        	<a href="index.html">
                            	Home
                            </a> 
							
                        </li>
                        <li class="dropdown">
                        	<a href="about-us.html">
                            	About Us
                            </a>                        
                        </li>
						<li class="dropdown">
                        	<a href="#">
                            	ASEAN Business Awards <br>Malaysia (ABAM) 2016
                            </a>
<ul><li class="dropdown"><a href="aboutaba2016.php">About ABAM 2016</a></li>
<!--<li class="dropdown"><a href="applyaba2016.php">Apply for ABAM 2016</a></li>-->
<!--<li class="dropdown"><a href="pastwinnersaba2016.php">Past ABAM Winners</a></li>-->
<li class="dropdown"><a href="past-aba-recipients.php">Past ABAM Recipients</a></li>

												<!--<li class="dropdown"><a href="http://aseanbac.com.my/aboutaba.php">ASEAN Business Awards </a>
													<ul>
														<li class="dropdown"><a href="http://aseanbac.com.my/aba-recipients.php">ABA 2015 Recipients</a></li>
														<li class="dropdown"><a href="http://www.aseanbac.com.my/Gallery-ABA-Gala2015.html ">ABA 2015 Photo Gallery</a></li>

													</ul>
												
												</li>-->
												
											</ul>                        
                        </li>
                        <li class="dropdown">
                        	<a href="#">
                            	Events
                            </a> 
							<ul>
								<li class="dropdown"><a href="upcomingevents.html">Upcoming Events</a>
									<ul>
										<li class="dropdown"><a href="abam2016event.php">ASEAN Business Awards Malaysia (ABAM) 2016</a>
											
										</li>
							
											

											
										
									</ul>
								</li>
								<li class="dropdown"> <a href="pastevents.html">Past Events</a>
									<ul>
										<li class="dropdown"><a href="aboutabis.php">ASEAN Business & Investment Summit (ABIS) 2015</a>
											<ul>
												<li class="dropdown"><a href="aboutabis.php">About ABIS</a></li>
												<li class="dropdown"><a href="abisprogramme.php">ABIS Programme </a></li>
												<li class="dropdown"><a href="speakers.php">ABIS Speakers</a>
													<ul>
														<li><a href="presentation-speeches.php">Presentation & Speeches</a></li>
														<li><a href="videos.php">Videos</a></li>
														<li><a href="doodles.php">Doodles</a></li>
													</ul>
												</li>
												<li class="dropdown"><a href="sponsor-partners.php">Sponsors & Partners </a></li>
												<li class="dropdown"><a href="GalleryList.html">Photo Album of ABIS 2015</a></li>
											</ul>
										</li>
										<li class="dropdown"><a href="aboutaba.php">ASEAN Business Awards (ABA)</a>
											<ul>
												<li class="dropdown"><a href="aboutaba.php">About ABA</a></li>
												<li class="dropdown"><a href="aba-programme.php">ABA Programme</a></li>
												<!--<li class="dropdown"><a href="aba-recipients.php">ABA 2015 Recipients</a></li>-->
												<li class="dropdown"><a href="abarecipients.php">Past ABA Recipients</a></li>
												<li class="dropdown"><a href="GalleryList.html">Photo Album of ABA 2015 </a></li>
											</ul>
										</li>
										<li class="dropdown"><a href="chairman-handover-gala-dinner.php">ASEAN-BAC 2015 Chairmanship Handover Gala Dinner</a></li>
										<li class="dropdown"><a href="abam-conference-on.php">About ASEAN-BAC Malaysia 2015 Conference on: SMEs and the AEC</a></li>
									</ul>
								</li>
							</ul>
							
                        </li>
                       <!--  <li class="dropdown">
                        	<a href="GalleryList.html">
                            	Gallery
                            </a>                            
                        </li> -->
                        <li class="dropdown">
                        	<a href="MediaCenter.html">
                            	Media Centre
                            </a>    
							<ul>
								<li><a href="GalleryList.html">Photo Gallery</a></li>
								<li><a href="video.php">Video Gallery</a></li>
								<li><a href="news.html">News</a>
									<ul>
										<li><a href="news.html">Print</a></li>
										<li><a href="broadcast.html">Broadcast</a></li>
									</ul>
								</li>
								
								<li><a href="Press.html">Press Releases</a></li>
								<li><a href="download.html">Downloads</a></li>
							</ul>
                        </li>
                        <li class="dropdown">
                        	<a href="contacts.html">
                            	Contact
                            </a>                     
                        </li>					
					</ul>
					</div><!-- end .span8 -->
				</div><!-- end .row -->		

				<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

			</div><!-- end #header -->