<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Programme</h1><br/><br/>
			<p>ASEAN BUSINESS & INVESTMENT SUMMIT (ABIS) AND ASEAN BUSINESS AWARDS (ABA) 2015<br/>20th - 21st NOVEMBER 2015<br/>SHANGRI-LA KUALA LUMPUR, MALAYSIA</p>
			<p><strong>NOTE:</strong> The ASEAN Business Advisory Council (ABAC) reserves the right to amend the programme and is not responsible for cancellations due to unforeseen circumstances.</p>
			<p>*This programme is subject to changes</p>

			<div id="tabs-1" class="tabs-container">
				<ul class="tabs-menu">
					<li class="active-tab"><a href="#tab-content-firtst-tab">DAY 1:Friday, November 20th 2015</a></li>
					<li><a href="#tab-content-second-tab">DAY 2:Saturday, November 21st 2015</a></li>
				</ul>
				<div class="clearfix"></div>
				<div id="tab-content-firtst-tab" class="tab-content" style="display: block;">
					<br/><br/><p>The first day's session of ABIS 2015 will focus on the progress that has been made by ASEAN thus far, and also identify and address the challenges that remain. In facing those challenges, has the ASEAN decision-making process been addressed? How can ASEAN learn from the experience of others and is ASEAN efficiently mobilizing its human capital?</p>
					<table class="table-bordered table-striped" width="100%">
						<tbody>
							<tr>
								<td width="250">09:00am</td>
								<td><strong>Welcome Speech by Chairman of ASEAN Business Advisory Council (ASEAN-BAC)</strong><br />
									Tan Sri Dato' Dr. Mohd Munir Abdul Majid</td>
							</tr>
							<tr>
								<td>09:10am</td>
								<td><strong>Opening Ceremony</strong><br />
									<strong>Keynote Speech by the 2015 ASEAN Chair</strong><br />
									The Honourable Prime Minister of Malaysia Dato' Sri Mohd Najib Tun Abdul Razak</td>
							</tr>
							<tr>
								<td>09:30am</td>
								<td><strong>Presentation of the ASEAN Business Awards (ABA) by the 2015 ASEAN Chair</strong><br />
									The Honourable Prime Minister of Malaysia Dato' Sri Mohd Najib Tun Abdul Razak
								</td>
							</tr>
							<tr>
								<td>10:15am</td>
								<td><strong>Launch of "Growth Accelerator Exchange" (GAX)</strong><br />
									The Honourable Prime Minister of Malaysia Dato' Sri Mohd Najib Tun Abdul Razak</td>
							</tr>
							<tr>
								<td>10:30am</td>
								<td><strong>Special Ministerial Panel with ASEAN Economic Ministers</strong><br />
									<p>2015 has been a significant year for ASEAN as it historically marks the culmination of efforts from the inception of an ASEAN Free Trade Area in 1992 to the realization of an ASEAN Economic Community (AEC) that envisions Southeast Asia as a single market and production base with free flow of goods, services and investments. </p>
									<p>As we enter the final lap and as attention now shifts to the post-2015 agenda of the ASEAN Economic Community (AEC), the burning question remains: Have the ambitious aspirations of deeper regional economic integration and community-building actually been achieved? </p>
									<p>This special ministerial panel session will examine the strengths, weaknesses, and shortcomings of both the ASEAN regional economic integration as well as the community-building process. It will also debate the thorny question of how much the regional has been prioritized over the national interests.</p>
									<p><strong><u>Moderator:</u></strong><br />
										Tan Sri Dr. Mohd Munir Abdul Majid, Chairman of ASEAN Business Advisory Council</p>
									<p><strong><u>Ministerial Panel:</u></strong></p>
									<ol>
										<li>H.E Sun Chanthol, Senior Minister and Minister of Commerce, Cambodia</li>
										<li>H.E. Mrs. Khemmani Pholsena, Minister of Industry and Commerce, Lao PDR</li>
										<li>H.E. Dato' Sri Mustapa Mohamed, Minister of International Trade and Industry, Malaysia</li>
										<li>H.E. Dr. Kan Zaw, Union Minister, Ministry of National Planning and Economic<br />
											Development, Myanmar</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td>11:30am</td>
								<td><strong>Presentations on:</strong>
									<ol>
										<li><strong>ASEAN Economic Community 2015: Progress and Key Achievements</strong><br />
											By H.E. Dr. Lim Hong Hin, Deputy Secretary-General for the ASEAN Economic<br />
											Community</li>
										<li><strong>ASEAN Integration Report 2015</strong><br />
											By H.E. Dr. Lim Hong Hin, Deputy Secretary-General for the ASEAN Economic<br />
											Community</li>
										<li><strong>ASEAN Investment Report 2015</strong><br />
											By Professor Hafiz Mirza, Investment and Enterprise Division, United Nations<br />
											Conference on Trade and Development (UNCTAD)</li>
										<li><strong>ASEAN Trade Repository, ASEAN Solutions for Investment, Services, and Trade<br />
												(ASSIST), ASEAN Customs Transit System</strong><br />
											By Paul Mandl, Team Leader of the ASEAN Regional Integration Support from the EU<br />
											(ARISE)</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td>12:00pm</td>
								<td><strong>An Indonesian Perspective on the Asean Economic Community (AEC)</strong><br />
									<p>As a founder and largest member state of ASEAN, with a population of 255 million and a<br />
									GDP of approximately USD900 billion, Indonesia is obviously its most critical component.<br />
									While Indonesian commitment to ASEAN is not doubted, it is important to understand<br />
									perspectives and evolution of policy on significant ASEAN initiatives such as the ASEAN<br />
									Economic Community.</p>
									<p><strong><u>Moderator:</u></strong><br />
										Tan Sri Rastam Mohd Isa, Chairman of Institute of Strategic and International Studies (ISIS)<br />
										Malaysia</p>
									<p><strong><u>Speaker:</u></strong><br />
										Gita Wirjawan, Founder &#038; Chairman Ancora Group (Minister of Trade of the Republic of<br />
										Indonesia, 2011-2014)</td>
							</tr>
							<tr>
								<td>12:45pm</td>
								<td><strong>Launch of:</strong>
									<ul>
										<li>"Economic Outlook for Southeast Asia, China and India 2016? by OECD: Organisation for Economic Co-operation and Development</li>
										<li>"Comprehensive Asia Development Plan 2.0? by ERIA: Economic Research Institute for ASEAN and East Asia</li>
									</ul>
									<p><strong><u>Moderator:</u></strong><br />
										Yumiko Murakami, Head of OECD, Tokyo Centre (Organisation For Economic Cooperation<br />
										And Development)</p>
									<p><strong><u>Speakers:</u></strong></p>
									<ol>
										<li>Rintaro Tamaki , Deputy Secretary-General of OECD (Organisation for Economic Cooperation and Development)</li>
										<li>Prof. Hidetoshi Nishimura , President of ERIA (Economic Research Institute for ASEAN<br />
											and East Asia)</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td>13:15pm</td>
								<td><strong>Networking Lunch</strong></td>
							</tr>
							<tr>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					<h4>ASEAN Business Awards (ABA) Gala Dinner</h4>
					<p><em><strong>*For a detailed programme on the ASEAN Business Awards Gala Dinner, please click <a href="aba-programme.php">here</a></strong></em></p>
					<table class="table-bordered table-striped" width="100%">
						<tbody>
							<tr>
								<td width="250">18:30pm</td>
								<td><strong>Registration and Networking Cocktails</strong></td>
							</tr>
							<tr>
								<td>19:30pm</td>
								<td><strong>ASEAN Business Awards Gala Dinner commences</strong>
									<ul>
										<li><strong>Welcome Speech by Chairman of ASEAN Business Advisory Council (ASEAN-BAC)</strong><br />
											Tan Sri Dato' Dr. MohdMunir Abdul Majid</li>
										<li><strong>Presentation of the ASEAN Business Awards (ABA)</strong></li>
										<li><strong>Presentation of the ASEAN-BAC ASEAN Lifetime Achievement Award</strong><br />
											To be presented by Chairman of ASEAN Business Advisory Council (ASEAN-BAC)<br />
											Tan Sri Dato' Dr. Mohd Munir Abdul Majid</li>
										<li><strong>Launch of ASEAN Young Entrepreneurs Council (AYEC)</strong><br />
											To be launched by H.E. Dato' Sri Mustapa Mohamed, Minister of International Trade and<br />
											Industry, Malaysia</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div id="tab-content-second-tab" class="tab-content" style="display: none;">
					<br/><br/><p>On the second day of ABIS 2015, focus will be on the sweeping changes taking place in the region. From the opportunities and challenges for MSMEs (Micro, Small and Medium Enterprises), to technological enablement, to massive urbanisation and sustainable development. </p>
					<p>The key drivers of these advancements will come from the youth and women and whilst ASEAN's growth is going to be astounding, it is by no means necessarily secured or secure, unless it is responsible growth. ASEAN's time has come, but these great prospects must not be marred.</p>
					<table class="table-bordered table-striped" width="100%">
						<tbody>
							<tr>
								<td width="250">10:00am</td>
								<td><strong>Address by Head of State</strong><br />
									Barack Obama<br />
									<p>President of the United States of America</p>
									<p><strong>Address by Head of State</strong><br />
										Shinzo Abe<br />
										Prime Minister of Japan</p>
									<p><strong>Address by Head of State</strong><br />
										Narendra Modi<br />
										Prime Minister of India</td>
							</tr>
							<tr>
								<td>12:30pm</td>
								<td><strong>SMEs &#8211; A Strategic Action Plan&#038; A Concrete Private Sector Initiative</strong><br />
									<p>There is now more focussed attention than ever, at last, on the micro, small and medium enterprises which form the backbone to the ASEAN economy. Increased awareness has led to the setting up and creation of multiple enablers and conduits to ease the challenges of operating a business. The SME Action Plan is being launched but more concretely the ASEAN Growth Accelerator is being set up by the private sector. There are various portals, platforms and websites being established. Things are finally happening in the MSME world. What more needs to be done though and how fast do we have to move in order to achieve success in the global marketplace?</p>
									<p><strong>Speech by Minister of International Trade &#038; Industry Malaysia</strong><br />
										YB Dato' Sri Mustapa Mohamed</p>
									<p><strong>Launch event of "ASEAN Strategic Action Plan for SME Development 2016-2025"</strong><br />
										<strong><u>To be launched in the presence of:</u></strong></p>
									<ol>
										<li>YB Dato' Sri Mustapa Mohamed, Minister of International Trade &#038; Industry Malaysia</li>
										<li>Tan Sri Dato' Dr. Mohd Munir Abdul Majid, Chairman, ASEAN Business Advisory Council<br />
											(ASEAN-BAC)</li>
										<li>Dr. Wimonkan Kosumas, Chair of Small and Medium Enterprises Working Group<br />
											(SMEWG)</li>
										<li>Dato' Hafsah Hashim, Chief Executive of SME Corp</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td>13:00pm</td>
								<td><strong>Luncheon</strong></td>
							</tr>
							<tr>
								<td>14:00pm</td>
								<td><strong>Thriving By Making Up Their Own Rules: Meet ASEAN's Dynamic, Determined And Driven Women Entrepreneurs</strong><br />
									<p>The number of women entrepreneurs in ASEAN is growing at an exponential level. Access to education, financing and a borderless technological world provides women with the tools to not only compete in the global marketplace, but also triumph. This session will unearth and showcase dynamic entrepreneurs in ASEAN, who just happen to be female, and are in fact ahead of the game in the ASEAN marketplace.</p>
									<p><strong><u>Moderator:</u></strong><br />
										Sophie Kamaruddin, Anchor &#038; Editor, Bloomberg TV Malaysia</p>
									<p><strong><u>Speakers:</u></strong></p>
									<ol>
										<li>Khine Thit Lwin, Executive Director, TMW Group of Companies</li>
										<li>Violet Lim, CEO of LunchClick &#038; Co-Founder of Lunch Actually</li>
										<li>Shinta Widjaja Kamdani, Chief Executive Officer, Sintesa Group</li>
										<li>Lilyana Abdul Latiff, Chief Executive Officer &#038; Founder, Aleph One</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td>14:30pm</td>
								<td><strong>The Phenomenon Of Urbanisation - Is ASEAN Ready?</strong><br />
									<p>ASEAN's population is becoming ever more urban. In 2013, the region had 317 million urban dwellers. By 2018, that number will rise to 345 million. That is around 5.5 million new urban dwellers in ASEAN every year-the equivalent of adding a new city with a population the size of Singapore every year. What do we need to do to manage this explosive growth? Is our planning and the infrastructures being rolled out robust enough? Are we ensuring responsible development and what lessons have we learned from cities that have failed? As we challenge ourselves to ensure quality of life for ASEAN's urban citizens, this begs the question: is growth with a conscience even possible?</p>
									<p><strong><u>Speaker:</u></strong><br />
										Oliver Tonby, Managing Partner, McKinsey &#038; Company in Southeast Asia
								</td>
							</tr>
							<tr>
								<td>14:50pm</td>
								<td><strong>The ASEAN Digital Leap &#8211; What&#8217;s In It For The Youth?</strong><br />
									<p>Digitalisation is changing the global landscape of how people do business, and ASEAN is no exception. Internet access is now a prerequisite in everyday life, despite more than 4billion people in the world yet to have internet presence. ASEAN, with its youthful population of more than 60% under 35 years old is widely recognised as the fastest growing internet and e-commerce market in the world. Digitalisation is said to level the playing field between existing bricks and mortar businesses and start-ups and micro businesses. As much as digitalisation is changing various aspects of business, ranging from financing requirements, access to market and transformation of operations, how is digitalisation promoting trade within the region? Are the young entrepreneurs capitalising on the regional market? What is needed to build a conducive ecosystem for ASEAN young entrepreneurs to capitalise on the 7th largest economy in the world?</p>
									<p><strong><u>Moderator:</u></strong><br />
										Syed Nabil Aljeffri, Secretary-General, ASEAN Business Advisory Council (ASEAN-BAC)</p>
									<p><strong><u>Speakers:</u></strong></p>
									<ol>
										<li>Hun Monivann, Chairman of Mega Leasing Plc., Vice President of SROCC (Siem Reap &#038;<br />
											Oddar Meanchey Chamber of Commerce)</li>
										<li>Dr. Chamnan Ngammaneeudom, Assistant Project Director of ASEAN SME Service<br />
											Center</li>
										<li>Richard Kok, Founder of iKargo</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td>15:20pm</td>
								<td><strong>In Conversation with Dr.Victor Gao: Is China&#8217;s Economy Slowing Down?</strong><br />
									<p>Growth in the world's second-largest economy has dropped to 7%, marking the slowest expansion in more than two decades. While Beijing seems keen to moderate growth to prevent the economy from entering a boom and bust cycle, is China's transition from the old to new growth models a sustainable one? How will this impact social stability? With the Chinese leadership under pressure to keep its economy on track, will current policy approaches be maintained? The million dollar question also remains: Is China's slowing down actually a blessing in disguise not only for its own good, but also ours?</p>
									<p><strong><u>Speaker:</u></strong><br />
										Dr. Victor Gao, Chairman of China Energy Security Institute &#038; Vice Chairman, Sino-Europe<br />
										United Investment Corporation</p>
									<p><strong><u>In Conversation With:</u></strong><br />
										Ho Kay Tat, Group Chief Executive Officer &#038; Publisher, The Edge Communications Sdn Bhd</td>
							</tr>
							<tr>
								<td>15:50pm</td>
								<td>
									<strong>Humanity's Biggest Challenge: Ensuring Sustainable Development For Future Generations</strong><br />
									<p>By 2030, 60 percent of the world's population will live in cities, up from about 50 percent today. Over the same period, more than two billion people are likely to enter the middle class, with the majority of them living in cities in emerging markets. The number of megacities with more than ten million people will continue to grow.  Congestion is also already close to unbearable in many cities and can cost as much as 2 to 4 percent of national GDP, by measures such as lost time, wasted fuel, and increased cost of doing business. </p>
									<p>Even though these numbers are staggering, the fruits of development efforts can still be sustainable in nature, from the economic, social and environmental aspect. Whilst this is easier said than done how is Japan leading the way in ensuring sustainable development and growth for its country? Having shown tremendous courage after World War II, the Japanese government has tended to mobilise all possible policy resources to demonstrate to the world a model which will underpin a good balance between sustainable development and economic growth. What are the latest developments in Japan's journey and how much of an influence can Japan have on the rest of Asia, particularly ASEAN?</p>
									<p><strong><u>Introduction by:</u></strong><br />
										Masayasu Hosumi, Chief Representative for ASEAN, President Bangkok Office, Japan<br />
										External Trade Organization (JETRO), Advisor for Chairman of Federation of Japanese<br />
										Chamber of Commerce and Industry in ASEAN (FJCCIA)</p>
									<p><strong><u>Presentations by:</u></strong></p>
									<ol>
										<li>Kazuya Kitae, Marketing Director, Panasonic Eco Solutions Malaysia Sdn. Bhd.</li>
										<li>Datuk Takashi Hibi, Advisor to Executive Committee, UMW Toyota Motor<br />
											Former Chairman of Federation of Japanese Chamber of Commerce and Industry in<br />
											ASEAN (FJCCIA), Former President of Japanese Chamber of Trade &#038; Industry, Malaysia<br />
											(JACTIM)</li>
									</ol>
								</td>
							</tr>
							<tr>
								<td>16:10pm</td>
								<td><strong>Closing Address</strong></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>