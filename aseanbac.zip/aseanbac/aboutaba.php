<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>

            <div class="row">
            	<div class="span5">
                	
                    <h1><strong>ASEAN Business Awards</strong></h1>

<p>
				<img alt="aba logo" src="_layout/images/aba_2015.png" class="responsive-img rounded image-center" style="width: 50%;">
			</p>
                    
                    
                    
                </div><!-- end .span5 -->
                <div class="span7">
                	
                    <div class="portfolio-item-slider">
                    	
                        <ul class="slides">
                        	<li>
                            	
                                <img src="http://aseanbac.com.my/images/ABA-Recipients-2015/ABA_Recipients_2015_040.jpg" alt="conference smes">
                                
                                <div class="slidetext">
                                	<h2><strong>ASEAN Business Awards</strong></h2>
                                </div><!-- end .slidetext -->
                                
                            </li>

<li>
                            	
                                <img src="http://aseanbac.com.my/images/ABA-Recipients-2015/ABA_Recipients_2015_049.jpg" alt="conference smes">
                                
                                <div class="slidetext">
                                	<h2><strong>ASEAN Business Awards</strong></h2>
                                </div><!-- end .slidetext -->
                                
                            </li>
 
                        </ul>
                        
                    </div><!-- end .portfolio-item-slider -->
                    
                </div><!-- end .span7 -->
            </div><!-- end .row -->
            
            <div class="row">
            	<div class="span12">
              <h1>Background</h1>
			<p>Since its establishment by ASEAN Leaders in 2003, the ASEAN Business Advisory Council (ASEAN-BAC) has been active in promoting public-private sector partnership and consultation to assist the integration of an ASEAN Economic Community (AEC) by 2015. In its efforts to bridge ASEAN Governments with its private sectors, the Council launched the ASEAN Business Awards (ABA) in 2007 to give recognition to enterprises that have contributed to the growth and prosperity of the ASEAN economy.</p>
			<p>ABA was conceived to be the first of its kind in the region, with the dual objectives of recognising outstanding ASEAN enterprises, and to serve as a platform to spread information concerning the ASEAN Economic Community (AEC). In addition, ABA also brings to the spotlight promising ASEAN small- and medium-sized enterprises (SMEs) that have the potential of becoming global economic players.</p>
			<p>A dedicated Working Group of 'National Gateways' consisting of ten ASEAN-BAC Members (one representative from each Member State) forms the foundation of ABA. The roles of the National Gateways are to promote the event in their respective countries, as well as to select 'National Judges' who will be responsible in selecting the recipients of ABA.</p>
			<p>Since it was first launched in 2007, ABA has recognised more than 60 companies throughout the region that excel in the categories of: Growth, Employment, Innovation and Corporate Social Responsibility (CSR). This year, however, ASEAN-BAC intends to expand categories of ABA to include the Priority Integration Sectors (PIS) of ASEAN element, as well as recognising outstanding young entrepreneurs and women entrepreneurs. In total, ABA 2015 will give out up to 18 (eighteen) awards to outstanding companies and individual entrepreneurs in the region.</p>
			<p>To ensure the high-quality and independency of such a prestigious event, ASEAN-BAC engages a Strategic Partner each year to administer the implementation of the ABA Framework; short listing nominations of companies; administering the Judges Meeting and assist in promoting the event throughout the ASEAN region. This Terms of Reference (ToR) aims to briefly highlight the event's objectives, categories and criteria, and tentative plan in carrying out ABA 2015.</p>
			
			<br/><br/>
			<h1>Objective</h1>
			<p>Aside from recognising outstanding ASEAN enterprises, ABA also has the objectives of serving as a platform to disseminate AEC-related information, as well as to bring to the spotlight SMEs that have the potential of becoming global economic players in their respective industries.</p>
			
			<br/><br/>
			<h1>The categories for 2015 ABA include the following:</h1>
			<ol class='ol-class'>
				<li>ASEAN Business Awards: Priority Integration Sectors - Excellence Awards;The Priority Integration Sectors Excellence Awards open to companies of all sizes, with one award to be given out per one sub-category. 12 Awards will be given out to each Priority Integration Sector which are Agro-Based, Automotive, Aviation, e-ASEAN, Electronics, Fisheries, Healthcare, Logistics, Rubber-based, Textiles, Tourism, and Wood-Based.</li>
				<li>ASEAN Business Awards: SME Excellence Awards;The SME Excellence Awards will be given to SMEs that meet SME Qualification that is set by SME Agencies in respective countries. One award will be given out per sub-category of 'Growth', 'Employment', 'Innovation', and 'Corporate Social Responsibility (CSR)'.</li>
				<li>ASEAN Business Awards: Young Entrepreneurs Award;The Young Entrepreneurs Award will be given to an outstanding young entrepreneur that fits the eligibility criteria for 'young entrepreneurs' set in earlier section. The nominees will be judged based on their achievements in relation to growth, employment, innovation, and CSR activities.</li>
				<li>ASEAN Business Awards: Women Entrepreneurs Award.Women Entrepreneurs Awards will be given to an outstanding women entrepreneur that fits the eligibility criteria under 'women entrepreneurs' set in earlier section. The nominees will be judged based on their achievements in relation to growth, employment, innovation, and CSR activities.</li>
				<li>ASEAN Business Awards: Friends of ASEAN Awards.Friends of ASEAN Awards will be given to three outstanding Non-ASEAN owned enterprises that fit the eligibility criteria under 'Friends of ASEAN' set in earlier section. The nominees will be judged based on their achievements in relation to growth, employment, innovation, and CSR activities.</li>
			</ol>
                    
                </div><!-- end .span12-->
            </div><!-- end .row -->            

  
            
 
		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

		</div><!-- end #content -->
<?php include "footer.php"; ?>