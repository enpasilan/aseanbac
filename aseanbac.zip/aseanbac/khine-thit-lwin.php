<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Khine Thit Lwin</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Khine Thit Lwin" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Khine Thit Lwin</strong>
					<br>
					EXECUTIVE DIRECTOR, TMW GROUP OF COMPANIES
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Born and raised in Yangon, Khine returned home in 2012 after graduating with Honors from Chapman University in Orange County, California, with a double major in Management and Marketing. She believed Myanmar was at a pivotal point, as the country was opening up for the first time, after its long history of isolation. Upon her return home, Khine joined TMW Group of Companies serving as the Executive Director, responsible for the Electronics arm of TMW.</p>
			<p>TMW is the number one Consumer Electronics Company in Myanmar and TMW Group of Companies consists of companies and business units across various industries such as Consumer Electronics Distribution and Retail, Construction Materials Manufacturing, Distribution and Retail, Real Estate, Resorts and Hospitality Management and Video and Music Production.</p>
			<p>Since joining TMW, her noteworthy achievements include delivering a sales growth of 80% during her first year at the company, initiating CSR programs to contribute back to the local community and establishing the first multi-brand Consumer Electronics retail chain store in Myanmar.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>