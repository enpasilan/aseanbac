<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>DAW NAN THAN HTWE</h2>
<div class="post-2225 page type-page status-publish hentry text-edit">
            

<p>Daw Nan Than Htwe was born in 1957 in Shan State. She graduated with a Bachelor of Education from Institute Of Education Yangon and started her career as a school teacher. She is married to U Aung Ko Win, a Shan native, and they have three daughters. In 1992, together with U Aung Ko Win they ventured into the mining business. Over the last two decades, the Shan couple had diversified their business interest extensively. They have created KBZ Group of Companies, one of Myanmar largest conglomerates with diversified interest in Banking, Insurance, Security &amp; Broking, Aviation, Property Development, Hotel and Tourism, Mining, Agriculture, Manufacturing, Trading, Infrastructure and Health Care.</p>
<p>Kanbawza Bank, also known as KBZ Bank, a member of the KBZ Group is by far means the largest and strongest bank in Myanmar and Myanmar�s highest tax contributor over the last three years. KBZ Bank has a branch network of 351 with more than 14,000 employees. KBZ Bank is recognised as �Myanmar Best Bank� by numerous international publications (Euromoney, Financial Times &ndash; The Banker, World Finance, Asian Banking &amp; Finance) for the last four consecutive years 2012 -2015.</p>
<p>Daw Nan Than Htwe�s philosophy on life evolves on commitment to family, work, and community service. It is this commitment and the belief that we �all have an obligation to give something of ourselves to our community,� that has helped to shape her role and actions. Daw Nan Than Htwe together with her family mooted the Brighter Future Myanmar Foundation in 2007, a non-profit organisation. As a champion of community development, improving health care quality, environmental conservation as well as leading voice for women�s equality, KBZ Group has allocated more than USD 98 million towards women�s health &amp; empowerment, education, disaster relief and recovery, environmental conservation and community development initiatives.
</p>

 
          </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>