<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>AIRASIA</h2>
                 <div class="post-2153 page type-page status-publish hentry text-edit">

<p>AIRASIA, the leading and largest low-cost airline group in Asia, services the most extensive network with over 100 destinations. Since its launch as a low-cost airline in 2001, AirAsia has carried more than 300 million guests. It has grown its fleet from two aircraft to more than 190, and its staff from 250 to 17,000 Allstars. The airline is proud to be a truly ASEAN airline and has established operations based in Malaysia, Thailand, Indonesia, Philippines and India, servicing a network spanning across ASEAN and reaching Northeast Asia, South Asia, the Middle East and Australia.</p>
<p>A home-grown, world class brand, AirAsia has been named as the World�s Best Low-Cost Airline for seven consecutive years (2009 &ndash; 2015) by London-based aviation research group Skytrax.</p>
<p>AirAsia has placed orders for more than 500 aircraft to support its plans to open new routes and increase frequencies where needed. It continues to explore ways to expand operations, including the possibility of opening new hubs and setting up new affiliates. The airline is focused on providing more and better services in its base ASEAN, home to 625 million people, and in neighboring markets, including China, India, Japan and South Korea which together with ASEAN host 3.3 billion people, or 47% of the world�s population.</p>
<p>AirAsia has is committed to ASEAN Community-building. The air links that AirAsia provides help bridge the communities of ASEAN: they bring families get together, facilitate business, support SMES, provide access to better healthcare and educational opportunities, create jobs, boost tourism, spur economic activity and contribute significantly to the coffers of ASEAN countries.</p>
<p>With its tagline �Now everyone can fly,� AirAsia holds fast to its aim of making air travel truly accessible to the 625 million people of ASEAN.</p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>