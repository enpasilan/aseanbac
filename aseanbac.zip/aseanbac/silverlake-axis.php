<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class='row'>
		<div class='span12'>
			<p>
				<a href="http://www.silverlakeaxis.com/" target="_blank"><img class="responsive-img rounded image-center" src="_layout/images/bg-body20.png" alt="silver lake axis logo"></a>
			</p>
			<p>Silverlake Axis creates technologies and build sustainable and dynamic environments to enable the Digital Economy. What sets Silverlake Axis apart is the foundation for its computing principles, which are grounded on mathematical theories ranging from Group and Category Theory to Topology. Through the years, Silverlake Axis has evolved using mathematics to refine, expand and invent technologies, broadening into new industries and markets at the same time.</p>
			<p>Founded in 1989, Silverlake Axis began its business in Malaysia and over the years, built an impeccable track record of successful core banking implementations. In less than two decades after its inception, over 40% of the top 20 largest banks in South-East Asia run Silverlake Axis core banking solution. Today, Silverlake Axis is the core system platform partner of choice for 3 of the 5 largest ASEAN super regional financial institutions.</p>
			<p>Silverlake Axis has been actively supporting ASEAN business communities through various forums to build regional capabilities and grow ASEAN enterprises. Silverlake Axis is proud to support ABIS as it is a key platform for ASEAN leaders, business leaders, entrepreneurs and decision makers to come together and work on initiatives that will support and transform ASEAN to become a truly regional and global economic force.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>