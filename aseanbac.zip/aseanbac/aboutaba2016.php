<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>

            <div class="row">
            	<div class="span12">
                	<p style="text-align:center;">
<img src="http://aseanbac.com.my/_content/abam2016/abam-logo-2016-new-min.png" style="width:50%;">
</p>
<br/>
                    <p><strong><center>31st May 2016 | Grand Hyatt Hotel Kuala Lumpur</center></strong></p>
 <p><strong><center>Guest of Honour: The Prime Minister of Malaysia, YAB Dato' Sri Mohd Najib Tun Abdul Razak </center></strong></p>

<p>Organised by the ASEAN Business Advisory Council (ASEAN-BAC) Malaysia, the seventh ASEAN Business Awards Malaysia (ABAM) recognises outstanding businesses and entrepreneurs that have created a positive impact on the growth of the Malaysian economy and helped elevate the country's image in ASEAN.</p>
<p>Recipients of the ABAM 2016 will also stand a chance to compete on the regional stage with ASEAN's best at the upcoming ASEAN Business Awards (ABA) 2016 in Laos at the end of this year. </p>
<p>Strategic partner Aljeffridean will audit all nominations, while a select panel of 4 judges - comprising of the country's top business leaders, economists and academics - will select the 19 award recipients.</p>
<p>The ASEAN Business Awards Malaysia aims to:</p>
<ul>
<li>recognise outstanding local enterprises and use it as a platform to spread knowledge about the ASEAN Economic Community (AEC);</li>
<li>inspire and rally Malaysian businesses to participate and become key players in the broader market;</li>
<li>strengthen over-all competitiveness of the Malaysian Businesses in the ASEAN Economic Community</li>

</ul>
<p>Malaysia aced at last year's <a href="http://www.aseanbac.com.my/Gallery-ABA-Gala2015.html">ASEAN Business Awards (ABA) 2015</a>, when eight (8) out of the total of twenty one (21) contested awards went to Malaysian companies; DRB-Hicom Berhad, AirAsia Berhad, QL Resources Berhad, Kossan Rubber Industries Bhd., Pointray (Malaysia) Sdn. Bhd., ProEightSdn. Bhd., ViTrox Technologies Sdn. Bhd., and VG Offshore Containers International (M) Sdn. Bhd. Tan Sri Rafidah Aziz was the recipient of the inaugural ASEAN Business Advisory Council's ASEAN Lifetime Achievement Award. </p>
<p>ABAM 2016 Award Recipients:</p>



<table class=GridTable5DarkAccent4 border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid white .5pt;
 mso-border-themecolor:background1;mso-yfti-tbllook:1184;mso-padding-alt:0in 5.4pt 0in 5.4pt'>
 <tr style='mso-yfti-irow:-1;mso-yfti-firstrow:yes'>
  <td width=601 colspan=3 valign=top style='width:450.8pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;mso-border-alt:solid white .5pt;mso-border-themecolor:
  background1;background:#806000;mso-background-themecolor:accent4;mso-background-themeshade:
  128;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;tab-stops:51.05pt;mso-yfti-cnfc:5'><b><span
  lang=EN-MY style='font-size:14.0pt;color:white;mso-themecolor:background1'>ASEAN
  BUSINESS AWARDS MALAYSIA (ABAM) 2016 AWARD RECIPIENTS<o:p></o:p></span></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:0'>
  <td width=601 colspan=3 valign=top style='width:450.8pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#BF8F00;mso-background-themecolor:
  accent4;mso-background-themeshade:191;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;tab-stops:121.85pt;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='font-size:13.0pt;color:white;mso-themecolor:background1'>ASEAN
  Excellence Award (2 awards)<o:p></o:p></span></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>1.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Malaysia</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>CIMB</span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>2.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>International</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Fraser &amp; <span class=SpellE>Neave</span>
  Holdings <span class=SpellE>Berhad</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3'>
  <td width=601 colspan=3 valign=top style='width:450.8pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#BF8F00;mso-background-themecolor:
  accent4;mso-background-themeshade:191;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:4'><b><span lang=EN-MY style='font-size:13.0pt;
  color:white;mso-themecolor:background1'>Entrepreneur of the Year (1 award)<o:p></o:p></span></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>3.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Entrepreneur of the Year</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span class=SpellE><span lang=EN-MY>YBhg</span></span><span
  lang=EN-MY>. Tan Sri <span class=SpellE>Dato</span>' Sri Leong Hoy <span
  class=SpellE>Kum</span></span></p>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span class=SpellE><i style='mso-bidi-font-style:
  normal'><span lang=EN-MY>Mah</span></i></span><i style='mso-bidi-font-style:
  normal'><span lang=EN-MY> Sing Group<o:p></o:p></span></i></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5'>
  <td width=601 colspan=3 valign=top style='width:450.8pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#BF8F00;mso-background-themecolor:
  accent4;mso-background-themeshade:191;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:4'><b><span lang=EN-MY style='font-size:13.0pt;
  color:white;mso-themecolor:background1'>Industry Excellence Award (12 awards)<o:p></o:p></span></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:6'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>4.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Agro-Based</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span class=SpellE><span lang=EN-MY>Batu</span></span><span
  lang=EN-MY> <span class=SpellE>Kawan</span> <span class=SpellE>Berhad</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:7'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>5.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Automotive</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span class=SpellE><span lang=EN-MY>Weststar</span></span><span
  lang=EN-MY> Auto <span class=SpellE>Sdn</span> <span class=SpellE>Bhd</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:8'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>6.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Aviation</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span class=SpellE><span lang=EN-MY>AirAsia</span></span><span
  lang=EN-MY> <span class=SpellE>Berhad</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:9'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>7.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Digital Media</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Sky Blue Media <span class=SpellE>Sdn</span> <span
  class=SpellE>Bhd</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:10'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>8.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>E-Commerce</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span class=SpellE><span lang=EN-MY>Dagang</span></span><span
  lang=EN-MY> Net Technologies <span class=SpellE>Sdn</span> <span
  class=SpellE>Bhd</span></span></p>
  </td>
  <a name="_GoBack"></a>
 </tr>
 <tr style='mso-yfti-irow:11'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>9.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Rubber-Based</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Top Glove Corporation <span class=SpellE>Berhad</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:12'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>10.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Healthcare</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span class=SpellE><span lang=EN-MY>Hovid</span></span><span
  lang=EN-MY> <span class=SpellE>Berhad</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:13'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>11.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>ICT</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span class=SpellE><span lang=EN-MY>Silverlake</span></span><span
  lang=EN-MY> Axis</span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:14'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>12.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Logistics</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span class=SpellE><span lang=EN-MY>Westports</span></span><span
  lang=EN-MY> Malaysia <span class=SpellE>Sdn</span> <span class=SpellE>Bhd</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:15'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>13.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Oil &amp; Gas</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span class=SpellE><span lang=EN-MY>SapuraKencana</span></span><span
  lang=EN-MY> Petroleum <span class=SpellE>Berhad</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:16'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>14.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Retail</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span class=SpellE><span lang=EN-MY>Valiram</span></span><span
  lang=EN-MY> Group</span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:17'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>15.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Tourism</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span class=SpellE><span lang=EN-MY>Genting</span></span><span
  lang=EN-MY> Malaysia <span class=SpellE>Berhad</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:18'>
  <td width=601 colspan=3 valign=top style='width:450.8pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#BF8F00;mso-background-themecolor:
  accent4;mso-background-themeshade:191;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:68'><b><span lang=EN-MY style='font-size:13.0pt;
  color:white;mso-themecolor:background1'>SME Excellence Award (4 awards)<o:p></o:p></span></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:19'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>16.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Growth</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Wide Tropism Trading <span class=SpellE>Sdn</span> <span
  class=SpellE>Bhd</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:20'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>17.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Innovation</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Builders Biomass <span
  class=SpellE>Sdn</span> <span class=SpellE>Bhd</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:21'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:4'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>18.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Employment</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFF2CC;mso-background-themecolor:accent4;mso-background-themetint:51;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal'><span lang=EN-MY>Natural Health Farm Marketing (M) <span
  class=SpellE>Sdn</span> <span class=SpellE>Bhd</span></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:22;mso-yfti-lastrow:yes'>
  <td width=47 valign=top style='width:35.2pt;border:solid white 1.0pt;
  mso-border-themecolor:background1;border-top:none;mso-border-top-alt:solid white .5pt;
  mso-border-top-themecolor:background1;mso-border-alt:solid white .5pt;
  mso-border-themecolor:background1;background:#FFC000;mso-background-themecolor:
  accent4;padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-yfti-cnfc:68'><b><span lang=EN-MY
  style='color:white;mso-themecolor:background1'>19.<o:p></o:p></span></b></p>
  </td>
  <td width=246 valign=top style='width:184.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Corporate Social Responsibility</span></p>
  </td>
  <td width=308 valign=top style='width:231.3pt;border-top:none;border-left:
  none;border-bottom:solid white 1.0pt;mso-border-bottom-themecolor:background1;
  border-right:solid white 1.0pt;mso-border-right-themecolor:background1;
  mso-border-top-alt:solid white .5pt;mso-border-top-themecolor:background1;
  mso-border-left-alt:solid white .5pt;mso-border-left-themecolor:background1;
  mso-border-alt:solid white .5pt;mso-border-themecolor:background1;background:
  #FFE599;mso-background-themecolor:accent4;mso-background-themetint:102;
  padding:0in 5.4pt 0in 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal;mso-yfti-cnfc:64'><span lang=EN-MY>Global Top Technologies (M) <span
  class=SpellE>Sdn</span> <span class=SpellE>Bhd</span> (GTC)</span></p>
  </td>
 </tr>
</table>






<p>For a copy of the ABAM 2016 Award Recipients, please click <a href="http://aseanbac.com.my/_content/events/ABAM_Programme_Book_2016.pdf" target="_blank">here</a>.</p>

                    
                    
                </div>
               
            </div><!-- end .row -->
            
                    

  
            
 
		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

		</div><!-- end #content -->
<?php include "footer.php"; ?>