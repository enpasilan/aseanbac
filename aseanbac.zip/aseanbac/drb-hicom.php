<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>DRB-HICOM</h2>
                  <div class="post-2148 page type-page status-publish hentry text-edit">
 
<p>DRB-HICOM BERHAD is one of the leading local conglomerates in Malaysia. The Group commands wide ranging businesses touching virtually every aspect of our lives. The Group comprises of more than ninety operating companies employing over 59 thousand workers, and is poised to help the nation surge ahead towards achieving developed nation status. The Group has interests and investments in major aspects of the economy. Prudent and inspired management of these core businesses and their subsidiaries anchor the Group firmly on track to participate in the growth and development of Malaysia.</p>
<p>At the core of the Group three sectors form the foundation of DRB-HICOM &ndash; Automotive; Services and Education; and Property, Asset and Construction &ndash; representing a diverse range of businesses that connect with our lives, directly or indirectly.</p>
<p>This broad, sound foundation has attracted firm investor interests at the Bursa Malaysia, marked by observers as �solid investment potential�. Investors know that with its far reach in many diverse industries, DRB-HICOM is positioned to capitalise fast and effectively to emerging opportunities in today�s rapidly changing, synergistic business environment.</p>
<p>Perhaps to illustrate DRB-HICOM�s far reaching business muscles, we may glance at three seemingly different business modules, all leading proponents in its niche sector.</p>
<p>Of the three core foundation of DRB-HICOM�s business, the automotive sector is the leading force. The Group operates the entire eco-system &ndash; from education, research, design and development, components manufacturing, assembly, quality control, marketing and sales, right up to after-sales service. Proton of course is a household name, but the Group has expanded its auto business to include other top marques such as Audi, Honda, Isuzu, JEEP, Mitsubishi, TATA and Volkswagen.</p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>