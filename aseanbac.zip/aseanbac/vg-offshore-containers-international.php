<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>VG OFFSHORE CONTAINERS INTERNATIONAL</h2>
              <div class="post-2217 page type-page status-publish hentry text-edit">
            
<p>For more than two decades, VG OFFSHORE CONTAINERS INTERNATIONAL has carved a solid reputation as a manufacturer of innovative, high quality, cost effective containers for the oil &amp; gas industry not only in the region but also globally.</p>
<p>Through the years, VG Offshore Containers or �VG� in short, has managed to stay ahead in the industry due to the company�s ability to provide total solutions in the design and production of a wide range of onshore and offshore containers and related products. From customised concept designs to fabrication and final assembly, VG products adhere to stringent quality and manufacturing standards that comply to DNV 2.7-1/ EN 12079, DNV 2.7-2, DNV 2.7-3 international quality certifications and other world class quality benchmarks.</p>
<p>Its state-of-the-art facility in Pulau Indah, Port Klang, Malaysia is fully fitted with the latest technology and equipment to ensure the highest manufacturing standards and processes. Product quality is second to none and beyond customers� expectations, thus ensuring continued support and demand worldwide.</p>
 
          </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>