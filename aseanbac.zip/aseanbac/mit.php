<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>MYANMAR INFORMATION TECHNOLOGY PTE LTD (MIT)</h2>
                <div class="post-2156 page type-page status-publish hentry text-edit">
            
<p>MYANMAR INFORMATION TECHNOLOGY PTE LTD (MIT) is the leading ICT solution provider in Myanmar, and it specializes in system integration, software development and strategic ICT solutions for business enterprises.</p>
<p>MIT was established in 1997 with the objective of promoting the ICT industry in Myanmar. Its goal is to succeed beyond Myanmar, to become first a regional, and then a global company, reaching the US and European markets.</p>
<p>MIT currently employs more than 300 professionals in four of its offices in Myanmar and a regional office in Singapore, serving both local and regional customers with strategic ICT products<br>
and services. MIT is a customer-centric organisation with major market share of software industry in Myanmar and its customers cover not only leading banks, retailers and conglomerates but also Small and Medium Enterprises (SME) which play an important role in inclusive social-economic development of the nation. MIT leverages mobility, cloud computing, business intelligence and social media trends to provide its clients and customers with competitive necessities and advantages as well as operation efficiency and effectiveness for long term sustainable success.</p>
<p>MIT is the first and the largest local partner of Microsoft and Oracle in Myanmar, providing comprehensive ICT solutions to the banking and financial services sector, retail sector, healthcare sector, hospitality sector, and public sector. MIT is also the largest Value Added Reseller (VAR) of SAP in Myanmar, providing Enterprise Resourcing Planning (ERP) implementation and consulting services to the customers. In addition, MIT has established strategic partnerships with regional ICT solution providers in Singapore, Malaysia and Thailand.</p>
<p>MIT believes in Corporate Social Responsibility (CSR) and is a member of United Nations Global Compact (UNGC). It is fully committed to human rights, labour, environment and anti-corruption principles. As part of its CSR activities, MIT has also contributed to the healthcare and education sector with ICT solutions and consulting services. </p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>