<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Dr. James Zhan</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="James Zhan" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Dr. James Zhan</strong>
					<br>
					Director of Division of Investment and Enterprise of UNCTAD
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>James Zhan is the Director of Investment and Enterprise at the United Nations Conference on Trade and Development (UNCTAD). He leads the team that produces the annual UN World Investment Report.</p>
			<p>Dr. Zhan has over two and a half decades of national and international experience in the areas of trade, investment, technology, business facilitation and enterprise development, including directing policy research, international consensus-building and technical assistance to governments, parliaments and institutions in over 160 countries. He led the formulation of global guidelines for a new generation of investment policies (the Investment Policy Framework for Sustainable Development), and the establishment of the biennial of the World Investment Forum.</p>
			<p>Dr. Zhan holds a number of advisory positions with academic institutions, including Cambridge University, Columbia University, Oxford University and the University of Geneva. He is also Global Agenda Council member of the World Economic Forum. He has published extensively on trade and investment-related economic and legal issues. Dr. Zhan is a regular speaker at academic, business and policy forums, as well as parliamentary hearings and appears frequently in international media outlets.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>