<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Doodles</h1><br/><br/>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>