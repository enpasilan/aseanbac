<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>G GEAR</h2>
                <div class="post-2160 page type-page status-publish hentry text-edit">
            
<p>G GEAR was founded in 2011 by a group of young dynamic people with strong commitment and passion. G Gear has its corporate office located in the heart of the Capital City, Phnom Penh, and six branches in high potential provinces in the Kingdom of Cambodia.</p>
<p>In the first year start, G Gear was allowed to bring only LG Mobile Communication to Cambodia�s market. At that time, it was tough to fight and survive in the market. However, with a strong team, G Gear now is the only strategic partner of LG Electronics in Cambodia. It not only offers the LG Mobile Communication but also LG Consumer Electronics, LG Commercial Air Conditioners and LG Hausys Window to the market. Moreover, recently G Gear has been partnering with other global brands such as Bosch Power Tools, Hyundai Elevator and British General (LED Lightening). Besides that, G Gear has also formed professional Mechanical and Engineering groups to provide premium service to customers. From year to year, G Gear has grown bigger and bigger, stronger and stronger; and it�s worth saying that G Gear is one of the biggest Electronic Distributors in the Kingdom of Cambodia under the clear organisational structure with more than 250 employees (in 2015).</p>
<p>G Gear�s vision is committed to being a leading electronic supplier in Cambodia that aces the satisfaction level and lives of its premium products and services. Until now, G Gear succeeded in opening five LG Brandshops in Cambodia. It continues to bring every customer in every province in the Kingdom of Cambodia to experience its products and services.�</p>
<p>Its people are on a mission to create value for its customers through the management of respecting human dignity and creation of impactful communication. G Gear�s unique code of conduct of ethical management allow it to constantly develop its capabilities in a more efficient way. </p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>