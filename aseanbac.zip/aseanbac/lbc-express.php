<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>LBC EXPRESS</h2>
               <div class="post-2172 page type-page status-publish hentry text-edit">
            
<p>For more than six decades, LBC EXPRESS has been moving lives, businesses, and communities. What started from a cargo and forwarding company in 1945 grew to become the Philippines� leading payments, remittance, courier, and logistics provider. It pioneered time-sensitive cargo delivery and 24-hour door-to-door delivery in the Philippines. LBC�s brand of exceptional customer service showcases a standard that even other companies try to achieve.</p>
<p>When LBC opened its first overseas branch in San Francisco, USA, it introduced the now-iconic Balikbayan Box, which was a convenient way for Overseas Filipinos to send items to their loved ones back home. The company opened more international branches in over 30 countries in the AsiaPacific, North America, the Middle East and Europe to serve the Filipino communities. It was then that LBC earned its popular moniker, �Hari ng Padala� (King of Delivery).</p>
<p>Aside from its courier and remittance services for individual Filipinos, LBC has also branched out into helping Filipino businesses reach new markets, both locally and internationally, through LBC Business Solutions. LBC Business Solutions offers value-added services such as warehousing, fulfillment processing, packaging and repacking, printing and mailing, and reverse logistics. The corporate logistics arm of LBC provides customizable and scalable business solutions for businesses of any size &ndash; from Micro, Small, and Medium Enterprises (MSMEs) to large corporations.</p>
<p>Despite the company�s success, LBC Express never forgets to give back to the people who have helped in its growth. Through the LBC Foundation, utilizing LBC�s vast network, resources, and 7,000-strong employees, the company initiates and executes outreach projects to aid the development of local communities, and to raise awareness for its major advocacies, such as sports and educational development.</p>
<p>Through LBC Express� constantly growing network of 6,400 locations, partners, and agents, the company continues to offer excellent timely service for Filipinos across the globe.</p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>