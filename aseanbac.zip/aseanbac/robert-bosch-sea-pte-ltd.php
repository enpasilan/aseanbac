<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>Robert Bosch (SEA) Pte. Ltd.</h2>
<div class="post-2234 page type-page status-publish hentry text-edit">
            
<p>BOSCH was set up in Stuttgart in 1886 by Robert Bosch (1861-1942) as �Workshop for Precision Mechanics and Electrical Engineering.� The special ownership structure of Robert Bosch GmbH guarantees the entrepreneurial freedom of the Bosch Group, making it possible for the company to plan over the long term and to undertake significant up-front investments in the safeguarding of its future.</p>
<p><em>Robert Bosch (South East Asia) Pte Ltd is a regional subsidiary of the Bosch Group, representing the Group�s interests in Southeast Asia, where it is currently present in Singapore, Malaysia, Indonesia, Thailand, Philippines, Vietnam, Brunei, Cambodia, Laos and Myanmar. Business operations in the 10 ASEAN countries report to Robert Bosch (SEA) Pte Ltd, located in Singapore. In fiscal 2014, the company generated SGD 260 million in sales in Singapore.* As per April 1, 2015 the regional headquarters employed over 910 associates. Bosch has been in Singapore since 1923, active in Automotive Aftermarket, Power Tools, Security Systems, Drive and Control Technology, Packaging Technology, Thermotechnology, as well as Software and Systems Solutions. The Asia<br>
Pacific headquarters for the Bosch business divisions of Automotive Aftermarket, Security Systems and Bosch Software Innovations, as well as operations for Corporate Research and Advance Engineering, and Information Technology, are part of Robert Bosch (SEA) Pte Ltd.</em></p>
 
          </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>