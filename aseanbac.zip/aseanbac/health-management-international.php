<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>HEALTH MANAGEMENT INTERNATIONAL</h2>
                <div class="post-2168 page type-page status-publish hentry text-edit">
            
<p>HEALTH MANAGEMENT INTERNATIONAL LTD (�HMI� or the �Group�) is a fast growing private healthcare provider listed on the SGX mainboard and an early champion of regionalisation as seen through its early investment into Malaysia via the acquisition of Mahkota Medical Centre (�Mahkota�) in 1998 and Regency Specialist Hospital (�Regency�) in 2007.Today, the two hospitals serve over 400,000 patients a year, including 80,000 patients from Indonesia, making it one of the leaders in medical tourism in Malaysia with a market share of more than 10%.</p>
<p>In Singapore, the Group owns and operates the HMI Institute of Health Sciences (�IHS�) to provide training and education for the local healthcare support sector. To date, IHS has trained over 3,500 graduates for the Singapore healthcare industry as well as approximately 100,000 people in emergency life support.</p>
<p>Many staff in their hospitals speak similar languages as their overseas patients in order to reduce communication barriers and provide higher quality of care. At the same time, the<br>
management team has had exposure and experience operating in key ASEAN markets, giving them an invaluable edge in navigating the cultural nuances found across the region. With its hospitals in Malaysia utilising a doctor-hospital partnership model adapted from Singapore�s private hospitals and supported by its network of 19 referral centres across Southeast Asia, 15 of which are in Indonesia, HMI is truly an ASEAN company</p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>