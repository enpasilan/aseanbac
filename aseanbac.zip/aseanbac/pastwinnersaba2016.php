<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>

            <div class="row">
            	<div class="span12">
                	
                    <h1><strong>ASEAN Business Awards - Past Winners</strong></h1>
<br/>

   <table width="996" class="table">
<tbody>
<tr>
<td width="246"><strong>Category</strong></td>
<td width="132"><strong>Criteria</strong></td>
<td width="186"><strong>Winner/Runner-Up</strong></td>
<td width="354"><strong>Company</strong></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132"></td>
<td width="186">Winner</td>
<td width="354">Singtel</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132"></td>
<td width="186">Winner</td>
<td width="354">CapitaLand</td>
</tr>
<tr>
<td width="246">Innovation</td>
<td width="132"></td>
<td width="186">Winner</td>
<td width="354">Zest-O Corporation</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132"></td>
<td width="186">Winner</td>
<td width="354">PT. Kalbe Farma Tbk</td>
</tr>
<tr>
<td width="996" colspan="4"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Alliance Global Group Inc.</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Keppel Offshore &amp; Marine Limited (Keppel O&amp;M)</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Martha Tilaar Group</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">The Bangchak Petroleum Public Company Limited</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Cherie Hearts Group International Pte. Ltd.</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Network Express Courier Services Pte Ltd.</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Pewter Art</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">The Wongpanit Garbage Recycle Separation Plant</td>
</tr>
<tr>
<td width="996" colspan="4"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Top Glove Corporation Berhad</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Tenaga Nasional Berhad</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">YCH Group Pte Ltd</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Keppel Land Limited</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Thu Duc Housing Development Corporation</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">KPJ Ampang Puteri Specialist Hospital</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">SeaBank</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Greenpac Pte Ltd</td>
</tr>
<tr>
<td width="996" colspan="4"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Charoen Pokphand Foods Public Co. Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner-Up</td>
<td width="354">PT. Bank Tabungan Pensiunan Nasional Tbk</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">CIMB Group Holdings</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner-Up</td>
<td width="354">PT. Bank Negara Indonesia Tbk</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">PT. Kalbe Farma Tbk</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner-Up</td>
<td width="354">Delta Electronics (Thai) Public Co. Limited</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">City Development Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner-Up</td>
<td width="354">Mitr Phol Dugar Corp. Limited</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">CV. Media Kreasi Bangsa</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner-Up</td>
<td width="354">Feinmetall Singapore</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">PT. Sarandi Karya Nugraha</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner-Up</td>
<td width="354">Achieve Group</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Rigel Technology Pte. Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner-Up</td>
<td width="354">PT. Jaty Arthamas</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Meritus Hotels &amp; Resorts</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner-Up</td>
<td width="354">Thumbprints Utd. Sdn. Bhd</td>
</tr>
<tr>
<td width="996" colspan="4"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Falcon Incorporation Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">ACLEDA Bank Plc</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Meritus Hotels &amp; Resorts</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PT Bank Negara Indonesia (Persero) Tbk</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">EEI Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">ACLEDA Bank Plc</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PT Kalbe Farma Tbk</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Jollibee Foods Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Meritus Hotels &amp; Resorts</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PT Bank Negara Indonesia (Persero) Tbk</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Top Glove Corporation Berhad</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">CapitaLand Limited</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">First Finance Plc</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Agrotech Vita Co., Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Lao Indochina Group Public</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Natural Health Farm Marketing SDN BHD</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">PT ESTETIKA SELARAS</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Feinmetall Singapore Pte Ltd</td>
</tr>
<tr>
<td width="246">Innovation Large</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Rigel Technology(s) Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Malaysia Microelectronic Solution Sdn Bhd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">PT Anugraha Wening</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">EPI Mobile Health Solutions Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">PT MagFood Inovasi Pangan</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Saigon Paper Joint Stock Company</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Siloso Beach Resort</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Adrenalin Events and Education Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132"></td>
<td width="186"></td>
<td width="354"></td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">OKH Global Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PetroVietnam Drilling &amp; Well Services Corp</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Serrano Holdings Pte Ltd</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Keppel Land Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Charoen Pokphand Foods Public Company Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Astro Malaysia Holdings Berhad</td>
</tr>
<tr>
<td width="246">Innovation</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">Delta Electronics (Thailand) Public Company Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">PT Dasa Windu Agung</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">DBS Bank</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">Large Company</td>
<td width="186">Recipient</td>
<td width="354">DBS Bank</td>
</tr>
<tr>
<td width="246">Growth</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">BMC Food Industries Sdn Bhd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">EON The Stakeholder Relations Firm</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Batamindo Shipping &amp; Warehousing Pte Ltd</td>
</tr>
<tr>
<td width="246">Corporate Social Responsibility</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Magsaysay Maritime Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">BMC Food Industries Sdn Bhd</td>
</tr>
<tr>
<td width="246">Innovation</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Rigel Technology(s) Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Biomax Tecnologies Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Alleira Batik</td>
</tr>
<tr>
<td width="246">Employment</td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Natural Health Farm Marketing Sdn Bhd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">Megamas Training Company Sdn Bhd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Recipient</td>
<td width="354">EON The Stakeholder Relations Firm</td>
</tr>
<tr>
<td width="246"></td>
<td width="132"></td>
<td width="186"></td>
<td width="354"></td>
</tr>
<tr>
<td width="246">ASEAN Centricity</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">UOB (United Overseas Bank)</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner Up</td>
<td width="354">Golden ABC, Inc</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Third</td>
<td width="354">Myanmar Airways International</td>
</tr>
<tr>
<td width="246">Corporate Excellence</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Keppel Land International Limited</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner Up</td>
<td width="354">International Container Terminal Services, Inc.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Third</td>
<td width="354">Kanbawza Bank Limited</td>
</tr>
<tr>
<td width="246">Innovation</td>
<td width="132">Large Company</td>
<td width="186">Winner</td>
<td width="354">Cyclet Electrical Engineering Pte Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Runner Up</td>
<td width="354">Pointwest Technologies Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">Large Company</td>
<td width="186">Third</td>
<td width="354">FAME Pharmaceuticals Industry Co., Ltd.</td>
</tr>
<tr>
<td width="246">Small &amp; Medium Enterprise</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Absolute Kinetics Consultancy Pte Ltd.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner Up</td>
<td width="354">Kelvin Chia Yangon Ltd.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Third</td>
<td width="354">VP Bank Securities Ltd.</td>
</tr>
<tr>
<td width="246">Women Leader</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Community Health Education Emergency Rescue Services (CHEERS)Corporation</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner Up</td>
<td width="354">City Mart Holding Co., Ltd</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner Up</td>
<td width="354">Southeast Asia Commercial Joint Stock Bank (SeABank)</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Third</td>
<td width="354">Surecatch World PTE</td>
</tr>
<tr>
<td width="246">Young Entrepreneur</td>
<td width="132">SME</td>
<td width="186">Winner</td>
<td width="354">Blue Ocean Operating Management Co., Ltd.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Runner Up</td>
<td width="354">Vintel Logistics Inc.</td>
</tr>
<tr>
<td width="246"></td>
<td width="132">SME</td>
<td width="186">Third</td>
<td width="354">Nghia Nippers Corporation</td>
</tr>
</tbody>
</table>
                    
                </div><!-- end .span5 -->
               
            </div><!-- end .row -->
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>