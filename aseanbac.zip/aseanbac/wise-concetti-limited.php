<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>WISE-CONCETTI LIMITED</h2>
             <div class="post-2221 page type-page status-publish hentry text-edit">
            
<p>WISE-CONCETTI LIMITED is one of the leading localisation service providers in Vietnam and South-East Asia. With a pool of more than 100 in &ndash;house linguists located in Vietnam, Indonesia, Thailand, Malaysia, Lao, Cambodia, Myanmar and Philippines, it provides all services in localisation including multi-sector document translation, website and software localisation, multilingual DTP, software testing and development, etc.</p>
<p>With solid teamsof experienced in-house linguists, a comprehensive quality management process, powered by cutting-edge localisation applications, it commits to provide clients with the best products and services. It has successfully developed and applied its own Project Management System (PMS) to ensure that all projects are processed and accomplished in a timely manner. The quality process strictly complies with EN 15038 Quality Standard and Quality Management Certificate ISO 9001:2008, which gives the most satisfaction to clients.</p>
<p>Its mission is to help global clients approach this developing market segment in the most effective way with the most competitive budget through its diverse and professional services. The company continuously improves its working process, appling advanced technologies with focus on human resources in order to best satisfy client needs.</p>
 
          </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>