<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>TAN SRI RAFIDAH AZIZ</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span9'>
			<h3 style="text-align: justify;">The 'ASEAN-BAC ASEAN Lifetime Achievement Award' is given to an individual who has shown outstanding leadership, passion and commitment and played an active role in realising the aims and purpose of ASEAN in areas relating to economic growth, social progress or the sociocultural evolution of ASEAN.</h3>
			<p> </p>
			<h4 style="text-align: justify;">
				<em>TAN SRI RAFIDAH AZIZ IS ONE OF MALAYSIA'S LONGEST-SERVING PUBLIC SERVANTS AND REGARDED BY MANY AS THE 'IRON LADY' FOR HER PRAGMATISM AND GOOD ARTICULATION. ASEAN BUSINESS ADVISORY COUNCIL (ASEAN-BAC) IS HONOURED TO AWARD THE LIFETIME ACHIEVEMENT AWARD TO TAN SRI RAFIDAH, IN RECOGNITION FOR HER TRAILBLAZING EFFORTS TO RAISE THE TRADE PROFILE OF MALAYSIA AND ASEAN.</em>
			</h4>
		</div>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="TAN SRI RAFIDAH AZIZ" src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/tansrirafidahaziz.jpeg">
				</div>
			</div>
		</div>
	</div>
	<div class='row'>
		<div class='span4'>
			<div style="text-align: justify;">
				In 1974,then Prime Minister of Malaysia, Tun Abdul Razak Hussein, appointed Tan Sri Rafidah as a Senator. At that time, she was only 31 years old and worked as an economics lecturer at the prestigious Universiti Malaya. As a young and budding public servant, Tan Sri Rafidah drove transformation across the trade industry in Malaysia and beyond.
				<p></p>
				<p>After serving as the Parliamentary Secretary to the Ministry of Public Enterprises in 1976 and subsequently promoted to Deputy Minister of Finance in 1977, Tan Sri Rafidah was made Minister of Public Enterprises in 1980. In 1987, Tan Sri Rafidah was appointed as the Minister for Trade and Industry (later re-designated as Minister of International Trade and Industry), a position she held until 2008.</p>
				<p>Admired by her peers and colleagues as a confident, dynamic, and passionate individual, Tan Sri Rafidah is also known for her no-nonsense approach when it comes to international trade negotiations.</p>
				<p>Coupled with her sound understanding of the public and private sector and over 20 years of experience in the Ministry, Tan Sri Rafidah brought significant changes to the economic landscape in the country. Her efforts to open the country to foreign investments, reduce trade barriers, tackle tough trade negotiations and free trade agreements (FTAs), have led the country to greater heights. One of the visible outcomes of her efforts is the setting up of manufacturing and research and development facilities by multinational brands such as Intel, Western Digital, Panasonic, Samsung, and many others.</p>
			</div>
		</div>
		<div class='span4'>
			<div style="text-align: justify;">
				Aside from implementing strategic trade policies that benefited businesses, Tan Sri Rafidah is a staunch believer in creating a conducive and opportune platform for companies to thrive and prosper. She played an instrumental role in the development of SMEs in Malaysia through the establishment of SMIDEC (now known as SME Corp). SMIDEC was formed as a specialised agency to promote the development of Small and Medium Industries (SMIs) in the manufacturing sector through the provision of advisory services, fiscal and financial help, infrastructural facilities, market access and other supporting programmes.
				<p></p>
				<p>Additionally, Tan Sri Rafidah was instrumental in establishing MATRADE (Malaysia External Trade Development Corporation), a trade agency aimed at raising the profile of Malaysian exporters in foreign markets.</p>
				<p>Under her watch and efforts, Malaysia emerged as the 20th largest trading nation globally, the world's largest exporter of semiconductors, and remains one of the world's most open economies. Tan Sri Rafidah has also been at the forefront of pushing the ASEAN and wider region agenda forward. Being one of the pioneers in Asia-Pacific Economic Cooperation (APEC), she championed Asia-Pacific trade as a driver of economic growth. Today, Malaysia and fellow APEC members account for about half of the global trade, 60 percent of total GDP, and much of the world's growth.</p>
			</div>
		</div>
		<div class='span4'>
			<div style="text-align: justify;">
				After ending her career in public service in 2008, Tan Sri Rafidah is now putting her years of experience in domestic and international trade to good use by assisting several companies across ASEAN to excel. In 2011, she was appointed as the Chairman of AirAsia X. Her mandate is to strengthen the company's governance and open up future routes for the airline to create a multitude of economic spin-off in the region.
				<p></p>
				<p>Tan Sri Rafidah is also serving as the Adjunct Professor at College of Business, University Utara Malaysia and Chairman for Megasteel Corporation, Pinewood Iskandar Malaysia Studio, and Supermax Corporation. Furthermore, she serves as the patron for the National Cancer Society of Malaysia, National Association of Women Entrepreneurs (PENIAGAWATI), The Pan-Pacific and South East Asia Women Associations of Malaysia (PPSEAWA) and as advisor to the Sarawak Renewable Energy Corridor (RECODA).</p>
				<p>As ASEAN Business Awards (ABA) continues its journey to recognise luminaries who played an instrumental role in the growth and prosperity of the region, we are proud to confer the 2015 ASEAN-BAC ASEAN Lifetime Achievement Award to Tan Sri Rafidah. Her astute skills and vision have benefited Malaysia and the region. It is through the efforts of towering figures such as Tan Sri Rafidah that ASEAN progresses and propels to greater heights.</p>
			</div>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>