<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Sponsors & Partners</h1><br/><br/>
		</div>
	</div>
	<div class="row">
		<center><h1>Sponsors</h1></center>
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="silverlake-axis.php">
						<img src="_layout/images/sponsorpartners/silverlake.jpg" alt="silverlake-axis">
					</a>
				</div>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="uem-group-berhad.php">
						<img src="_layout/images/sponsorpartners/UEMGroupLogo.jpg" alt="uem-group-berhad">
					</a>
				</div>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="yayasan-albukhary-foundation.php">
						<img src="_layout/images/sponsorpartners/Yayasan-albukhary-foundation.jpg" alt="yayasan-albukhary-foundation">
					</a>
				</div>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="https://www.tm.com.my" target="_blank">
						<img src="_layout/images/sponsorpartners/TM_logo.jpg" alt="Day 1">
					</a>
				</div>
			</div>
		</div>
	</div><br/><br/>
	<div class="row">
		<center><h1>Strategic Partner</h1></center>
		<div class="span12">
			<div class="span4">
				&nbsp;
			</div>
			<div class="span4">
				<div class="photo-cover">
					<a href="http://www.bdo.my/" target="_blank">
						<img src="_layout/images/sponsorpartners/BDO.jpg" alt="Day 1">
					</a>
				</div>
			</div>
			<div class="span4">
				&nbsp;
			</div>
		</div>
	</div><br/><br/>
	<div class="row">
		<center><h1>Supported by</h1></center>
		<div class="span12">
			<div class="span2">
				&nbsp;
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="Gallery-ABIS-Day1.html">
						<img src="_layout/images/sponsorpartners/ASEAN-Malaysia-Chairmanship.jpg" alt="Day 1">
					</a>
				</div>
			</div>
			<div class="span2">
				&nbsp;
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="http://www.miti.gov.my/" target="_blank">
						<img src="_layout/images/sponsorpartners/MITI.jpg" alt="Day 1">
					</a>
				</div>
			</div>
			<div class="span2">
				&nbsp;
			</div>
		</div>
		
		
	</div>
	<div class="row">
		<div class="span12">
			<div class="divider single-dotted"></div>
			<p>For sponsorship and partnership opportunities, please email secretariat@aseanbex.com to discuss further.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>