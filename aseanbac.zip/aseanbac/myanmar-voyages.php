<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>MYANMAR VOYAGES</h2>
              <div class="post-2184 page type-page status-publish hentry text-edit">
            
<p>MYANMAR VOYAGES is the prestigious leading ground tour operator in Myanmar, offering inbound and outbound exclusive tours. Established in 1996, Myanmar Voyages is a 100% privately owned company with experienced multilingual staff engaging in Yangon Head Office with operation units in Bagan, Mandalay and Inle. It is recognised as the pioneer marketer to Spanish, Northern Europe, and South American visitors, thus seeking to become a globally accepted to DMC. With extensive recognition in the Travel Industry, it organises Cruise Ships calling Yangon Port and arrange with machinate Destination Management to the highest standard. Its dedicated and innovative team holds the promise to deliver the very best service to each customer. It contributes to local charities, develops in house training, and is always aware of ever growing environmental issues in globalisation. The company was awarded 2014 winner of The Best Performance Tour Operator in Myanmar selected by Ministry Of Hotel and Tourism and UNWTO recently.</p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>