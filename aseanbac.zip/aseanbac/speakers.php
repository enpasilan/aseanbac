<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Faces of ABIS 2015</h1>
		</div>
	</div>
	<div class="row">
		<center><h1>Keynote Speakers</h1></center>
		<div class="span12">
			<div class="span4">
				&nbsp;
			</div>
			<div class="span4">
				<div class="photo-cover">
					<a href="dato-seri-najib-tun-abdul-razak.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/najib-razak.jpg" alt="najib razak">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="dato-seri-najib-tun-abdul-razak.php">YAB Dato' Sri Najib Tun Abdul Razak</a></strong>
				</h3>
			</div>
			<div class="span4">
				&nbsp;
			</div>
		</div>
		
		<div class="span12">
			<div class="span2">
				&nbsp;
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="tan-sri-dr-mohd-munir-majid.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/tsmunir.jpg" alt="tsmunir">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="tan-sri-dr-mohd-munir-majid.php">YBhg Tan Sri Dr. Mohd Munir Abdul Majid</a></strong>
				</h3>
			</div>
			<div class="span2">
				&nbsp;
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/datuk-seri-mustapa-mohamed.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Y.B Dato' Sri Mustapa Mohamed</a></strong>
				</h3>
			</div>
			<div class="span2">
				&nbsp;
			</div>
		</div>
	</div>
	
	<div class="row">
		<center><h1>Speakers</h1></center>
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/obama.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Barack Obama</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/abe.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Shinzo Abe</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/modi.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Narendra Modi</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="chanthol-sun.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/ABIS_Speaker_H.E.SUN-Chanthol.jpg" alt="Chanthol SUN">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="chanthol-sun.php">HE Sun Chanthol</a></strong>
				</h3>
			</div>
		</div>
		
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="lim-hong-hin.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/LIM-HONG-HIN.jpg" alt="Lim Hong Hin">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="lim-hong-hin.php">Dr. Lim Hong Hin</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="james-zhan.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/James-Zhan.jpg" alt="James Zhan">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="james-zhan.php">Dr. James Zhan</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="paul-mandl.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/Paul-Mandl.jpg" alt="Paul Mandl">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="paul-mandl.php">Paul Mandl</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="gita-irawan-wirjawan.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/09/gita-wirjawan.jpg" alt="Gita Wirjawan">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="gita-irawan-wirjawan.php">Gita Wirjawan</a></strong>
				</h3>
			</div>
		</div>
		
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="tan-sri-rastam-mohd-isa.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/Tan-Sri-Rastam.jpg" alt="Tan Sri Rastam Mohd Isa">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="tan-sri-rastam-mohd-isa.php">Tan Sri Rastam Mohd Isa</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/10/mr_tamaki.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Rintaro Tamaki</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="prof-hidetoshi-nishimura.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/10/Speaker_High-Res-Photo_ERIA_Prof-Nishimura.jpg" alt="Hidetoshi Nishimura">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="prof-hidetoshi-nishimura.php">Prof. Hidetoshi Nishimura</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="yumiko-murakami.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/murakami2.jpg" alt="Yumiko">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="yumiko-murakami.php">Yumiko Murakami</a></strong>
				</h3>
			</div>
		</div>
		
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="khine-thit-lwin.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/10/Knine_Thit.jpg" alt="Khine Thit Lwin">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="khine-thit-lwin.php">Khine Thit Lwin</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="violet-lim.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/10/violet_lim.jpg" alt="violet-lim">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="violet-lim.php">Violet Lim</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/Speaker_Photo_Shinta-Widjaja-Kamdani_resized.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Shinta Widjaya Kamdani</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/ABIS_Speaker_Photo_Sophie-Kamaruddin.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Sophie Kamaruddin</a></strong>
				</h3>
			</div>
		</div>
		
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/LilyInRS.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Lilyana Abdul Latiff</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/09/Oliver-Tonby.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Oliver Tonby</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="syed-nabil-aljeffri.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/syed-nabil-aljefri.jpg" alt="syed-nabil-aljeffri">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="syed-nabil-aljeffri.php">Syed Nabil Aljeffri</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/hun-monivann.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Hun Monivann</a></strong>
				</h3>
			</div>
		</div>
		
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/Dr-Chamnan.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Dr. Chamnan Ngammaneeudom</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/richard-kok.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Richard Kok</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/victor-gao1.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Victor Gao</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/Peo-Ho-Kay-Tat-2014-2.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Ho Kay Tat</a></strong>
				</h3>
			</div>
		</div>
		
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/Mr.-Hosumi.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Masayasu Hosumi</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/Mr.-Kitae.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Kazuya Kitae</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/11/Datuk-Hibi.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Datuk Takashi Hibi</a></strong>
				</h3>
			</div>
		</div>
		<p>*Speakers for ABIS 2015 is currently being finalised and will be updated on this page from time to time.</p>
	</div>
	
	<div class="row">
		<center><h1>Past Speakers of ABIS</h1></center>
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="syed-nabil-aljeffri.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/syed-nabil-aljefri.jpg" alt="syed-nabil-aljeffri">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="syed-nabil-aljeffri.php">Syed Nabil Aljeffri</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="dr-surin-pitsuwan.php">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/dr-surin-pitsuwan.jpg" alt="dr-surin-pitsuwan">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="dr-surin-pitsuwan.php">Dr. Surin Pitsuwan</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/hillary-clinton.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Hillary Rodham Clinton</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/nguyen-tan-dung21.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">H.E Nguyen Tan Dung</a></strong>
				</h3>
			</div>
		</div>
		
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/02/Thein-Sein.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">H.E. U Thein Sein</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/richard-bolt.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Richard Bolt</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/lili-yan-ing.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Dr. Lili Yan Ing</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/Prof.-Hidetoshi-Nishimura.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Prof. Hidetoshi Nishimura</a></strong>
				</h3>
			</div>
		</div>
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/victor-tarusin.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Victor Tarusin</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/dato-hafsah.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Dato Hafsah</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/lisa-mihardja.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Lisa Mihardja</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/datp-paduka-hj-ali-hj-apong.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Ym Dato Paduka Hj Ali bin Hj Apong</a></strong>
				</h3>
			</div>
		</div>
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/Fauziah-DSP-Hj-Talib.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Fauziah DSP Hj Talib</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/u-win-myint.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">H.E U Win Mying</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/JUNIE-DEL-MUNDO.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Junie Del Mundo</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/sam-kimnot-vey-sure.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Sam Kim</a></strong>
				</h3>
			</div>
		</div>
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/francisco-sanchez.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Francisco Sanchez</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/H.E-Anad-sharma.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">H.E Anand Sharma</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/Dermot-Mannion-Royal-Brunei.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Dermot Mannion</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/alexander-bohmer.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Alexander B?hmer</a></strong>
				</h3>
			</div>
		</div>
		<div class="span12">
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/prakash-chandran.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">Prakash Chandran</a></strong>
				</h3>
			</div>
			<div class="span3">
				<div class="photo-cover">
					<a href="javascript:void(0)">
						<img src="http://www.coachhub.com.my/abiscom/wp-content/uploads/2015/03/Hun_Sen2.jpg" alt="Image">
					</a>
				</div>
				<h3 class='text-center'>
					<strong><a href="javascript:void(0)">H.E. Samdech Decho Hun Sen</a></strong>
				</h3>
			</div>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>