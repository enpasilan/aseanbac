<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>U THADOE HEIN</h2>
<div class="post-2225 page type-page status-publish hentry text-edit">
            

<p>U Thadoe Hein is the founder and the chairman of Myanma Awba Group, one of the largest agriculture companies in Myanmar.</p>
<p>Myanma Awba Group is serving three million farming families (out of seven million farming families in the country) with agricultural input, finance and extension services. The core products and services include fertilizers, crop protection chemicals, hybrid and OP seeds, agricultural finance and micro loans, mobile based payment system and farm advisory services.</p>
<p>Starting as a trading company in 1995, the group grows exponentially with the investments in the first privately owned fertilizer plant, chemical formulation plants and research and development facilities. The group also has the largest agronomist team (1000+) in ASEAN.</p>
<p>The group aims to increase agriculture output of farmers, lower cost and increase efficiency. The primary objective is to help farmers prosper and alleviate poverty.</p>
<p>Every year, Myanma Awba set aside a large percent of net profit as the corporate social responsibility budget for building of infrastructure and public utilities in rural areas to primarily focus on:</p>
<ul>
<li>Access Roads to major villages</li>
<li>Bridges on the access roads</li>
<li>Electrification &ndash; installation of transformers and generators</li>
<li>Drinking Water in Dry Zones (by building tube wells and water distribution system)</li>
<li>Ambulance &ndash; for transporting patients from rural area to nearby towns with adequate hospital and medical care</li>
<li>Schools and libraries &ndash; to foster education in rural Myanmar &ndash; increased focus</li>
</ul>
<p>Having graduated from the University of Yangon in 1995 and Executive MBA from the Yangon Institute of Economics in 2008, U Thadoe Hein is married to Daw Soe Mar Lar and has three sons.</p>

 
          </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>