<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>SL AGRITECH CORPORATION</h2>
                  <p>SL AGRITECH CORPORATION (SLAC) is a private company engaged in the research, development, production and distribution of hybrid rice seed and premium quality rices. SLAC was established in September 2000 under the ownership and management of Sterling Paper Group of Companies. Although relatively new in the rice industry, SLAC has proven its competitive edge in the local and international platform. Apart from it being an ISO certified rice company, it is also the largest local hybrid rice seed company in the Philippines and tropical Asia, and a market leader in premium quality rice. SLAC is the first local company to export high quality milled rice in the country. Moreover, SLAC is the only local company which has a fully-integrated operation system that develops and oversees the whole rice processing system from research and development to packing and distribution. It has three local production sites: a 40-hectare Research and Demonstration farm at Barangay Oogong, Sta. Cruz, Laguna; a 600-hectare production area located in Lupon, Davao Oriental; and a 6-hectare rice processing plant in Talavera, Nueva Ecija. Its products include hybrid rice seeds SL-8H, SL-18H, and SL-12H; Dona Maria Jasponica, Miponica, and Cherry Blossoms Rices. SLAC works with several partners to boost the adoption of hybrid rice technology. Together with the Department of Agriculture and its hybrid rice program, SLAC strives to pursue its vision of a rice self-sufficient and hunger-free world.</p>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>