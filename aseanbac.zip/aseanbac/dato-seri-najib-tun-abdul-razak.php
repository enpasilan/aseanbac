<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Dato' Seri Najib Tun Abdul Razak</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="najib razak" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Dato' Seri Najib Tun Abdul Razak</strong>
					<br>
					Prime Minister of Malaysia
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Dato' Seri Haji Mohammad Najib bin Tun Haji Abdul Razak is the sixth and current Prime Minister of Malaysia. He was sworn in to the position on 3 April 2009 to succeed Abdullah Ahmad Badawi. He is the President of the United Malays National Organisation, the leading party in Malaysia's ruling Barisan Nasional coalition.</p>
			<p>Najib is the eldest son of Abdul Razak Hussein, Malaysia's second Prime Minister, and the nephew of Hussein Onn, Malaysia's third. He was elected to the Parliament of Malaysia in 1976, at the age of 23, replacing his deceased father in the Pahang-based seat of Pekan. From 1982 to 1986 he was the Menteri Besar (Chief Minister) of Pahang, before entering the federal Cabinet of Mahathir Mohamad in 1986 as the Minister of Culture, Youth and Sports. He served in various Cabinet posts throughout the remainder of the 1980s and 1990s, including as Minister for Defence and Minister for Education. He became Deputy Prime Minister on 7 January 2004, serving under Prime Minister Abdullah Ahmad Badawi, before replacing Badawi a year after Barisan Nasional suffered heavy losses in the 2008 election.</p>
			<p>Najib's tenure as Prime Minister has been marked by economic liberalisation measures, such as cuts to government subsidies, loosening of restrictions on foreign investment, and reductions in preferential measures for ethnic Malays in business. His Barisan Nasional coalition was re-elected at the 2013 election, albeit with a reduced majority due in large part to a substantial movement of urban voters to opposition parties.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>