<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>COLOR SILK</h2>
              <div class="post-2180 page type-page status-publish hentry text-edit">
            
<p>Launched in 2009, COLOR SILK is a social business, with its social mission oriented to preserving a silk weaving culture that was at risk of vanishing, while reducing poverty and contributing to economic development in more isolated areas.</p>
<p>Today, Color Silk Co.,Ltd has 450 women silk weaver members and 125 household farmers who grow the mulberry tree, and rearing the cocoons located in Takeo province. The business operates<br>
in seven rural villages outside of Phnom Penh, Cambodia. Color Silk creates employment opportunity for women providing stable income for these vulnerable groups of people in the rural areas.</p>
<p>The women create beautiful silk products and Color Silk ensures that:</p>
<ul>
<li>The women get to work in respectable conditions: they get technical and financial supports to set up the loom in their house and to buy raw materials, as well as training in the overall processes of weaving with entrepreneurial concept.</li>
<li>Price guarantee: The price that Color Silk offers for their products is sufficient to generate an income.</li>
</ul>
<p>Color Silk Enterprise is finally selling these products to wholesalers, retailers to boutiques in Phnom Penh and in Siem Reap and exporting to international market based in EU (Denmark,<br>
Germany, French, Italy) United State, in Asia included Japan.</p>
<p>Color Silk works to improve women standard of living, local economic development, as well as to protect the environment and to provide environmental-friendly products for public consumers. </p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>