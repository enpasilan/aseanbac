<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>
            
            <div class="row">
            	<div class="span12">
                	
                    <h1><strong>Videos</strong></h1>

<div class="col-md-12">
				 
					<div class="post-344 page type-page status-publish hentry text-edit">
						<div class="span12"><div class="span4"> <iframe width="100%" height="280" frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/v8wJcrGI-Ps"></iframe><p></p>
<h4>Highlights of ABIS 2015</h4>
<p></p></div><div class="span4"> <iframe width="100%" height="280" frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/VRqLsAdwdmI"></iframe><p></p>
<h4>ASEAN Business Awards (ABA) 2015 Gala Dinner &ndash; 20 November 2015, Shangri-La Kuala Lumpur Malaysia</h4>
<p></p></div><div class="span4"> <iframe width="100%" height="280" frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/lSc8q9oBLIc"></iframe><p></p>
<h4>ASEAN BUSINESS AWARDS 2015 &ndash; Press Conference</h4>
<p></p></div></div>
<div class="clearfix"></div>
<div class="span12"><div class="span4"> <iframe width="100%" height="280" frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/OrH5e3qR51A"></iframe><p></p>
<h4>ASEAN Business Club- Concluding Remarks</h4>
<p></p></div><div class="span4"> <iframe width="100%" height="280" frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/Rswa_M1xKuo"></iframe><p></p>
<h4>7 Things you need to know about ASEAN</h4>
<p></p></div><div class="span4"> <iframe width="100%" height="280" frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/dBksWxH3ocU"></iframe><p></p>
<h4>East Asia 2012 &ndash; ASEAN Connectivity: Roadmap to 2015</h4>
<p></p></div></div>
<div class="clearfix"></div>
<div class="span12"><div class="span4"> <iframe width="100%" height="280" frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/xrl-TX2Gmxc"></iframe><p></p>
<h4>ASEAN 2015</h4>
<p></p></div><div class="span4"> <iframe width="100%" height="280" frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/ag_WjlJJNU0"></iframe><p></p>
<h4>Davos 2015 &ndash; The ASEAN Agenda</h4>
<p></p></div></div>
<div class="clearfix"></div>
 
					</div>
								</div>   
			
                    
                </div>
            </div><!-- end .row -->
 
            
 
		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

		</div><!-- end #content -->
<?php include "footer.php"; ?>