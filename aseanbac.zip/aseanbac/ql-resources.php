<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>QL RESOURCES</h2>
                <div class="post-2164 page type-page status-publish hentry text-edit">
            
<p>QL RESOURCES is a sustainable and scalable multinational agro-food corporation that farms and produces some of the most resource-efficient protein and food energy sources. The Group has three principal activities; Integrated Livestock Farming, Marine Products Manufacturing and Palm Oil Activities. QL has operation centres in Malaysia, Indonesia, Vietnam and China.</p>
<p><em><strong>Marine Products Manufacturing Activities</strong></em><br>
Marine Products Manufacturing�s integrated upstream and downstream activities include deep-sea fishing, marine prawn aquaculture farming, surimi and fishmeal production and consumer foods.</p>
<p><em><strong>Integrated Livestock Farming Activities</strong></em><br>
Organic growth and a series of strategic acquisitions has driven QL�s rise to become one of Malaysia�s leading operators in animal feed raw materials and poultry farming. QL is among ASEAN�s leading poultry egg producers with a group production rate of 4.5 million eggs per day.</p>
<p><em><strong>Palm Oil Activities</strong></em><br>
QL has two independent Crude Palm Oil (CPO) mills servicing small and medium sized estates in the Tawau and Kunak regions of Sabah, East Malaysia. QL also has one CPO mill in Eastern Kalimantan, Indonesia. QL owns a 1,200 hectare palm oil estate in Sabah, as well as 15,000 hectare plantation (currently under development) in Eastern Kalimantan, Indonesia.</p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>