<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>POINTRAY</h2>
              <div class="post-2188 page type-page status-publish hentry text-edit">
            
<p>POINTRAY (MALAYSIA) SDN BHD is a versatile manufacturing company led by Dato� Maziah Haji Musa who sets the direction, promotes clear and visible values and has high expectations to inspire and motivate the workforce.</p>
<p>Established in 1992, Pointray (Malaysia) Sdn Bhd started as a small cottage industry driven by local demand in tailoring and production of textile based products. In 1996, foreseeing a promising potential domestic demand of products such as mattresses and cushions it ventured into high resilient foam-based products. In 2008, the company�s activities further diversified into the production of polypropylene furniture particularly for schools, learning institutions and offices. In 2010, it started its metal steel division while in 2011 marks its journey into wood based furniture meeting demand from government and private sector. </p>
<p>After more than two decades, Pointray (Malaysia) Sdn Bhd has expanded rapidly and diversified from its humble beginnings of tailoring and manufacturing textile-based products that are still running in tandem with its new involvement in the manufacturing of green and innovative kenaf products. It continues to strive in becoming the leading one stop center for the east coast region in manufacturing variety of furniture that meets the requirement of the domestic, government and global market. Pointray (Malaysia) Sdn Bhd also aims to be the leader in manufacturing kenaf products in the commercial industry for the global market using advanced automation green technology.In 2013, In line with the Government�s Global Warming Policy, the company embarked into Kenaf Industry and is now considered pioneering in kenaf bio-composite, kenaf based raw materials and kenaf based products in Malaysia. The introduction of kenaf as an alternative to timber based products would be instrumental in alleviating the shortage of forest based raw materials. Concurrently, Pointray is also active in providing domestic services such as providing hire/maintenance of furniture for local learning institutions nationwide. </p>
 
          </div>

                    
                </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>