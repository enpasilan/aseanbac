<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Prof. Hidetoshi Nishimura</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Hidetoshi Nishimura" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Prof. Hidetoshi Nishimura</strong>
					<br>
					President, Economic Research Institute for ASEAN and East Asia (ERIA)
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Graduated from the Faculty of Law, the University of Tokyo. Joined the Ministry of International Trade and Industry in 1976. Has assumed numerous positions, including Representative of the Asia-Pacific Region of the Japan Overseas Development Corporation, Director of the Southeast Asia and Pacific Division of the Trade Policy Bureau, Vice Governor for International Affairs of Ehime Prefecture, Director-General of the Business Support Department of the Small and Medium Enterprise Agency, Executive Managing Director of the Japan-China Economic Association, and President of the Japan-China Northeast Development Association. Assumed position of ERIA Executive Director in June 2008 and ERIA President in June 2015. Visiting Professor of Waseda University, Darma Persada University, Miyazaki Sangyo-Keiei University and Fellow of Meiji Institute for Global Affairs, Meiji University.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>