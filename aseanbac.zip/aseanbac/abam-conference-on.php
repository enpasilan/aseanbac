<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>

            <div class="row">
            	<div class="span5">
                	
<h1><strong>About ASEAN-BAC Malaysia 2015 Conference on: SMEs and the AEC</strong></h1><br/><br/>
			<p>The ASEAN SME Conference was held following the ASEAN-BAC 2015 Chairmanship Handover Gala Dinner. The Conference discussed the opportunities and challenges facing ASEAN SMEs and how to address them.</p>
			<p>The SMEs are recognised as the primary driver for economic growth and employment, and the Conference provided substantive and conclusive discussions and recommendations which was subsequently forwarded to the ASEAN Heads of Government.</p>
			<p>Some speakers included YB Dato' Sri Mustapa Mohamed, Honourable Malaysian Minister of International Trade and Industry; Tan Sri Tony Fernandes, Group CEO of AirAsia; Pak Gita Wirjawan, Former Trade Minister of the Republic of Indonesia; Tengku Dato' Zafrul Bin Tengku Abdul Aziz , Acting Chief Executive of CIMB Group Holdings Bhd / Chief Executive of CIMB Investment Bank Bhd, among many others.</p>
			<p><a href='Gallery-Event-2.html' class='btn text-uppercase'>View Photo Gallery</a></p>
                    

                    
                </div><!-- end .span5 -->
                <div class="span7">
                	
                    <div class="portfolio-item-slider">
                    	
                        <ul class="slides">
                        	<li>
                            	
                                <img src="_content/events/670x670-conference.jpg" alt="conference smes">
                                
                                <div class="slidetext">
                                	<h2><strong>Conference</strong></h2>
                                </div><!-- end .slidetext -->
                                
                            </li>
 
                        </ul>
                        
                    </div><!-- end .portfolio-item-slider -->
                    
                </div><!-- end .span7 -->
            </div><!-- end .row -->
            
         

  
            
 
		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

		</div><!-- end #content -->
<?php include "footer.php"; ?>