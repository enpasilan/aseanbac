<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>
            
            <div class="row">
            	<div class="span12">
                	
                   <br/>

<p style="text-align: center;">
<img style="width:30%;" src="http://aseanbac.com.my/_content/abam2016/abam-logo-2016-new-min.png">
</p>
<br>

                    <p style="text-align: center;"><strong>31st May 2016 | Grand Hyatt Hotel Kuala Lumpur</strong><p>
<p style="text-align: center;"><strong>Guest of Honour: The Prime Minister of Malaysia, YAB Dato' Sri Mohd Najib Tun Abdul Razak</strong><p>

<p>Organised by the ASEAN Business Advisory Council (ASEAN-BAC) Malaysia, the seventh ASEAN Business Awards Malaysia (ABAM) recognises outstanding businesses and entrepreneurs that have created a positive impact on the growth of the Malaysian economy and helped elevate the country's image in ASEAN.</p>
<p>Recipients of the ABAM 2016 will also stand a chance to compete on the regional stage with ASEAN's best at the upcoming ASEAN Business Awards (ABA) 2016 in Laos at the end of this year.</p>
<p>The ASEAN Business Awards Malaysia aims to:</p>
<ul>
<li>recognise outstanding local enterprises and use it as a platform to spread knowledge about the ASEAN Economic Community (AEC);</li>
<li>inspire and rally Malaysian businesses to participate and become key players in the broader market;</li>
<li>strengthen over-all competitiveness of the Malaysian Businesses in the ASEAN Economic Community</li>

</ul>
<p style="text-align: center;">For more information on ASEAN Business Awards Malaysia (ABAM) 2016,<br/>please click <a href="http://aseanbac.com.my/aboutaba2016.php">here</a>.</p>
		
			
                    
                </div>
            </div><!-- end .row -->
 
            
 
		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

		</div><!-- end #content -->
<?php include "footer.php"; ?>