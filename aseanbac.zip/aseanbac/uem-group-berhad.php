<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>UEM Group Berhad</h1><br/><br/>
			<p>
				<a href="http://www.uem.com.my/" target="_blank"><img class="responsive-img rounded image-center" src="_layout/images/bg-body20.png" alt="uem logo"></a>
			</p>
			<p>We are UEM Group Berhad, Malaysia's leading engineering-based infrastructure and services group with an established track record and global operations.</p>
			<p>We have the ability, expertise and resources to deliver and manage key infrastructure development projects and services for the public and private sectors spanning expressways, bridges, buildings, urban transits, water infrastructure, airports, hospitals, township & property development and asset & facility management services.</p>
			<p>From our beginnings in 1966, we have grown to become an international business operating in emerging and matured economies focusing on four key businesses namely Expressways, Township & Property Development, Engineering & Construction and Asset & Facility Management. We operate via 20 major operating companies, 3 of which are listed on local and international bourses, and we have human resource of more than 15,000 including 2,500 technical professionals. Our headquarters and core geographic market is Malaysia with presence in various countries around the globe including Brunei, India, Indonesia, Singapore, Canada, Australia, United Kingdom, New Zealand and the Middle East.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>