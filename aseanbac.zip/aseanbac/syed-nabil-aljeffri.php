<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Syed Nabil Aljeffri</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Syed Nabil Aljeffri" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Syed Nabil Fauwaz Aljeffri</strong>
					<br>
					Secretary-General, ASEAN-BAC. Council Member, ASEAN-BAC Malaysia.
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Syed Nabil Aljeffri is a UK trained lawyer, currently active in private equity, being the head of structuring and acquisitions for a boutique Private Equity firm based in Malaysia with primary interests in healthcare, property and ICT.</p>
			<p>He is also Head of Corporate Services and Legal Compliance for AljeffriDean Chartered Accountants, Chairman of Eco-Hygiene Systems Sdn. Bhd. and a director of several other private limited companies. He has also served as Member of various council secretaries including the Malaysia-Venezuela Business Council and the Malaysia-China Business Council.</p>
			<p>Syed Nabil has spearheaded numerous initiatives including business seminars, forums, corporate functions and exhibitions, most recently as Chairman of the 1st and 2nd ASEAN-Malaysia Business Seminar in collaboration with the Ministry of International Trade and Industry Malaysia. He also founded the Malaysian Association of Asean Young Entrepreneurs.</p>
			<p>Nabil is actively involved in various ASEAN initiatives in and out of the region in various speaking and working group capacities. He has served on the ASEAN Business Advisory Council (ASEAN-BAC) since 2009, as a member of the secretariat until his appointment as a Council Member in 2012. Nabil currently serves as Council Member of ASEAN-BAC Malaysia and Secretary General of ASEAN-BAC.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>