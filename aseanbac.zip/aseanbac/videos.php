<?php include "header.php"; ?>
<?php
$videos = array(
    array(
	'title' => 'ABIS 2015: Welcome Speech by Chairman of ASEAN Business Advisory Council (ASEAN-BAC) & Keynote Speech by the 2015 ASEAN Chair, Prime Minister of Malaysia',
	'id' => 'g-76faRwJ9w',
    ),
    array(
	'title' => 'ABIS 2015 : Address by Barack Obama, President of United States of America',
	'id' => 'YIpSW7qMFdo',
    ),
    array(
	'title' => 'ABIS 2015: Address by Prime Minister Shinzo Abe & Address by Prime Minister Narendra Modi',
	'id' => 'tc9NO6LlZ9U',
    ),
    array(
	'title' => 'ABIS 2015 : "Special Ministerial Panel with ASEAN Economic MInisters"',
	'id' => 'FVAlKC4gXOA',
    ),
    array(
	'title' => 'ABIS 2015 : Presentations by representative from ASEAN Secretariat, UNCTAD and EU-ARISE',
	'id' => '4cWnXjjYmKc',
    ),
    array(
	'title' => 'ABIS 2015 : "An Indonesian Perspective on the ASEAN Economic Community (AEC)" with Gita Wirjawan',
	'id' => '5q6YG5eTp5A',
    ),
    array(
	'title' => 'ABIS 2015 : Launch of Reports by ERIA & OECD',
	'id' => 'k_mohgzAMjg',
    ),
    array(
	'title' => 'ABIS 2015 : Launch of "ASEAN Strategic Action Plan for SME Development 2016-2025"',
	'id' => 'uJOfzA6I2zY',
    ),
    array(
	'title' => 'ABIS 2015 : Meet ASEAN\'s Dynamic, Determined And Driven Women Entrepreneurs',
	'id' => 'cb768Og7gB4',
    ),
    array(
	'title' => 'ABIS 2015: "The Phenomenon Of Urbanisation - Is ASEAN Ready?" by Oliver Tonby',
	'id' => 'Q80UXMnKxYg',
    ),
    array(
	'title' => 'ABIS 2015: "The ASEAN Digital Leap - What\'s In It For The Youth?"',
	'id' => 'CRquBq8idD8',
    ),
    array(
	'title' => 'ABIS 2015: "In Conversation with Dr. Victor Gao: Is China\'s Economy Slowing Down?"',
	'id' => '3A9LyG_tyZE',
    ),
    array(
	'title' => 'ABIS 2015 : "Humanity\'s Biggest Challenge: Ensuring Sustainable Development For Future Generations"',
	'id' => 'Wh4JLyESgvc',
    ),
);

$total_videos = sizeof($videos) - 1;
?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Videos</h1><br/><br/>
		</div>
	</div>
<!--	<div class="row">-->
		<?php
		$video_counter = 0;
		foreach($videos as $key=>$value){
			$video_counter = $video_counter==3?0:$video_counter;
			if($video_counter == 0){?>
				<div class="row"><div class="span12">
			<?php } ?>
					<div class="span4">
						<iframe width="100%" height="280" src="http://www.youtube.com/embed/<?php echo $value['id']; ?>"></iframe>
						<h3><?php echo $value['title']; ?></h3>
					</div>
			<?php if($video_counter == 2 || $key == $total_videos){?>
					</div></div>
			<?php } ?>
		<?php $video_counter++; } ?>
	<!--</div>-->
</div>
<?php include "footer.php"; ?>