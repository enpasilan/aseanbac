<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Gita Irawan Wirjawan</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Gita Wirjawan" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Gita Irawan Wirjawan</strong>
					<br>
					Founder & Chairman, Ancora Group, and former Minister of Trade of the Republic of Indonesia
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Mr. Gita Wirjawan is the Chairman of Ancora Group, an Indonesian business group with interests in private equity investing, natural resources, real estate, sports, and music, which he founded in 2007. A statesman, entrepreneur, investment banker and musician, Mr. Wirjawan's career spans the highest levels of government and business.</p>
			<p>Prior to resuming his role at Ancora, Mr. Wirjawan served as Minister of Trade of the Republic of Indonesia. Previously, he served as Chairman of the Investment Coordinating Board of Indonesia (BKPM). For his extraordinary accomplishments as a cabinet member, President Susilo Bambang Yudhoyono awarded him the Bintang Mahaputra Adipradana.</p>
			<p>As an investment banker, he has held key appointments at Goldman Sachs and JPMorgan. Mr. Wirjawan played leading roles in many mergers, corporate restructuring, corporate financing and strategic sales involving leading companies in Southeast Asia. His various board roles included service as a Commissioner of state-owned oil giant, Pertamina, and as an Independent Board Director of Axiata Group Berhad.</p>
			<p>Outside the world of business, his passion lies in philanthropy, education, sports, and music. As a philanthropist, he has endowed scholarships for Indonesians to attend the best universities in the world, including Harvard, Stanford, Oxford, Cambridge, and Science Po. He is also in the process of establishing 1,000 kindergartens throughout Indonesia. An avid golfer, he has established academies to groom future Indonesian golfers. He is also currently Chairman of the Indonesian Badminton Association. And through Ancora Music, he has produced a range of albums that have been critically acclaimed. Mr. Wirjawan is a member of the advisory board of the Institute for Societal Leadership at Singapore Management University and a member of the Dean's Leadership Council at the S. Rajaratnam School of International Studies at Nanyang Technological University. He is a member of the international advisory board of ACE Group and the Center for Strategic and International Studies. Previously, he served on the Dean's Leadership Council at the Harvard Kennedy School.</p>
			<p>He holds a BS from the University of Texas at Austin, an MBA from Baylor University, and an MPA from the Harvard Kennedy School. He has an honorary doctorate in business administration from Naresuan University, Thailand. He qualified as a Certified Public Accountant in the State of Texas, USA, and holds a Chartered Financial Analyst designation.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>