<?php include "header.php"; ?>
<div id="content">
<br/><br/>

            <div class="row">
            	<div class="span12">
                  <h2>PRUDENTIAL CORPORATION ASIA</h2>
<div class="post-2242 page type-page status-publish hentry text-edit">
            
<p>PRUDENTIAL CORPORATION ASIA is a business unit of Prudential plc (United Kingdom)*, comprising its life insurance operations in Asia, and its asset management business, Eastspring Investments. It is headquartered in Hong Kong.</p>
<p>Prudential is a leading life insurer that spans 12 markets in Asia, covering Cambodia, China, Hong Kong, India, Indonesia, Korea, Malaysia, the Philippines, Singapore, Taiwan, Thailand and Vietnam. Prudential has a robust multi-channel distribution platform providing a comprehensive range of savings, investment and protection products to meet the diverse needs of Asian people.</p>
<p>Eastspring Investments manages investments across Asia on behalf of a wide range of retail and institutional investors. It is one of the region�s largest asset managers with operations in 10 markets plus offices in North America, the UAE, the UK and Luxembourg. It has �85.3 billion (about US$134.1 b) in assets under management (as at 30 June 2015), managing funds across a range of<br>
asset classes including equities and fixed income.</p>
<p><em>* Prudential plc is not affiliated in any manner with Prudential Financial, Inc., a company whose principal place of business is in the United States of America.</em></p>
<p>Prudential plc is listed on the stock exchanges of London (PRU.L), Hong Kong (2378.HK), Singapore (K6S.SG) and New York (PUK.N)</p>
 
          </div>
               
            </div>
            

		</div><!-- end #content -->
<?php include "footer.php"; ?>