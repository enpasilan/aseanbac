<?php include "header.php"; ?>
<?php
$pns = array(
    'Presentations'=>array(
	array(
	    'name'=>'Presentation by Deputy Secretary General Lim Hong Hin',
	    'dl_name'=>'[Download PPT]',
	    'dl_link'=>'#',
	),
	array(
	    'name'=>'Presentation by Prof. Hafiz Mirza',
	    'dl_name'=>'[Download PPT]',
	    'dl_link'=>'#',
	),
	array(
	    'name'=>'Presentation by Paul Mandl',
	    'dl_name'=>'[Download PPT]',
	    'dl_link'=>'#',
	),
	array(
	    'name'=>'Presentation by Rintaro Tamaki',
	    'dl_name'=>'[Download PPT]',
	    'dl_link'=>'#',
	),
	array(
	    'name'=>'Presentation by Prof. Hidetoshi Nishimura',
	    'dl_name'=>'[Download PPT]',
	    'dl_link'=>'#',
	),
	array(
	    'name'=>'Presentation by Datuk Takashi Hibi',
	    'dl_name'=>'[Download PPT]',
	    'dl_link'=>'#',
	),
    ),
    'Speeches'=>array(
	array(
	    'name'=>'Welcome Speech by Chairman of Asean Business Advisory Council,<br/>Tan Sri Dato\' Dr. Mohd Munir Abdul Majid,',
	    'dl_name'=>'[Download PDF]',
	    'dl_link'=>'#',
	),
	array(
	    'name'=>'Remarks by President Obama<br/>at ASEAN Business & Investment Summit 2015',
	    'dl_name'=>'[Download PDF]',
	    'dl_link'=>'#',
	),
	array(
	    'name'=>'Address by Prime Minister Narendra Modi<br/>on the Occasion of the ASEAN Business & Investment Summit 2015',
	    'dl_name'=>'[Download PDF]',
	    'dl_link'=>'#',
	),
	array(
	    'name'=>'Address by Prime Minister Shinzo Abe<br/>on the Occasion of the ASEAN Business & Investment Summit 2015',
	    'dl_name'=>'[Download PDF]',
	    'dl_link'=>'#',
	),
    ),
);
?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Presentations & Speeches</h1><br/><br/>
			<?php foreach($pns as $topic=>$value){?>
				<h2><?php echo $topic; ?></h2>
				<ol class="ol-class">
					<?php foreach($value as $key=>$subtopic){?>
						<li><?php echo $subtopic['name']; ?><br/><a href="<?php echo $subtopic['dl_link']; ?>"><?php echo $subtopic['dl_name']; ?></a></li>
					<?php } ?>
				</ol>
			<?php } ?>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>