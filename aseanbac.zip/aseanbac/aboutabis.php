<?php include "header.php"; ?>
<div id="content">
		
		<!-- /// CONTENT  /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<br/><br/>
            
            <div class="row">
            	<div class="span5">
                	
                    <h1><strong>About ABIS 2015</strong></h1>

			<p>The ASEAN Business and Investment Summit (ABIS) 2015 is ASEAN's premier annual Business and Investment event.</p>
			<p>The summit provides a platform for the business community to engage with ASEAN leaders, business leaders, entrepreneurs and key decision makers.</p>
			<p>ABIS 2015 will bring into sharp focus the opportunities, requirements and questions facing the private sector, and explore the myriad of possibilities brought forth by the onset of the ASEAN Economic Community (AEC).</p>
			<p>The ASEAN Business and Investment Summit 2015 is also the platform for business leaders to meet with global and regional leaders from different investment, business and academic backgrounds. ABIS 2015 will allow you to explore new ideas, challenge perspectives, outline opportunities, network and most importantly, attain the necessary insights to propel your business towards regional success.</p>
		



			<p><a href='Gallery-Event-1.html' class='btn text-uppercase'>View Photo Gallery</a></p>
                    
                </div><!-- end .span5 -->
                <div class="span7">
                	
                    <div class="portfolio-item-slider">
                    	
                        <ul class="slides">
                        	<li>
                            	
                                <img src="http://aseanbac.com.my/images/ABIS/Day1/ABIS_Day1_063.jpg" alt="abis2015">
                                
                                <div class="slidetext">
                                	<h2><strong>ABIS 2015</strong></h2>
                                </div><!-- end .slidetext -->
                                
                            </li>



<li>
                            	
                                <img src="http://aseanbac.com.my/images/ABIS/Day1/ABIS_Day1_032.jpg" alt="abis2015">
                                
                                <div class="slidetext">
                                	<h2><strong>ABIS 2015</strong></h2>
                                </div><!-- end .slidetext -->
                                
                            </li>
 
                        </ul>
                        
                    </div><!-- end .portfolio-item-slider -->
                    
                </div><!-- end .span7 -->
            </div><!-- end .row -->
		</div>
<?php include "footer.php"; ?>