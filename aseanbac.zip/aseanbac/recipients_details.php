<?php
$name = $_GET['name'];
$type = $_GET['type'];
$main_dir = 'ABA_2015_Recipients/';

$details_path = $main_dir.$name.'/details.txt';
$details = file_get_contents($details_path);
?>

<?php include "header.php"; ?>
<?php if($type == 'company'){
	$logo = $main_dir.$name.'/logo.png';
	$logo_link_path = $main_dir.$name.'/logo_link.txt';
	$logo_link = file_get_contents($logo_link_path);?>
	<div id="content">
		<br/><br/>
		<div class="row">
			<div class="span12">
				<h1><?php echo $this_page; ?></h1><br/><br/>
				<p>
					<a href="<?php echo $logo_link; ?>" target="_blank"><img class="responsive-img rounded image-center" src="<?php echo $logo; ?>" alt="<?php echo $this_page; ?>"></a>
				</p>
				<?php echo $details; ?>
			</div>
		</div>
	</div>
<?php }elseif($type == 'individual'){
	$image = $main_dir.$name.'/image.png';
	$image_caption_path = $main_dir.$name.'/image_caption.txt';
	$image_caption = file_get_contents($image_caption_path);?>
	<div id='content'>
		<br/><br/>
		<div class='row'>
			<div class='span12'>
				<h1><?php echo $this_page; ?></h1>
			</div>
		</div>
		<div class='row'>
			<div class='span3'>
				<div class="team-member">
					<div class="team-member-thumb">
						<img alt="<?php echo $this_page; ?>" src="<?php echo $image; ?>">
					</div>
					<p>
						<?php echo $image_caption; ?>
					</p>
				</div>
			</div>
			<div class='span9'>
				<?php echo $details; ?>
			</div>
		</div>
	</div>
<?php } ?>
<?php include "footer.php"; ?>