<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Violet Lim</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Violet Lim" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Violet Lim</strong>
					<br>
					CEO of LunchClick & Co-Founder of Lunch Actually
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Violet Lim is CEO & Co-Founder of Lunch Actually, Asia's first lunch dating company that aims to help busy professionals find love by arranging one-to-one lunch dates with compatible matches among the pre-screened clientele who meet each other's dating criteria. Today, Lunch Actually is Asia's biggest premier lunch dating company with offices in Singapore, Hong Kong, Kuala Lumpur, Penang and Jakarta with the largest lunch dating membership base. Together with her husband Jamie Lee, Violet also founded eSynchrony to fill the gap in the market for trusted online and offline dating service platforms and LunchClick, a dating app for serious daters.</p>
			<p>The first Asian to be certified by the Matchmaking Institute in New York City, Violet has gained tremendous insight into the dating and matchmaking industry and is the pioneer in her field. She has appeared in over 2500 media coverages in top magazines, television and radio, and featured in local and international media such as The Straits Times, ABC News 20|20, CNBC Asia, BBC, Bloomberg and Radio Australia. She was also featured in Singapore's National Day video in 2005 as one of Singapore's most aspiring people. Previously a columnist on the relationship Q&A in Cittabella Malaysia, New Man Malaysia and HerWorld.com, she now writes a monthly column for a Malaysian Chinese newspaper.</p>
			<p>Violet has a Masters degree in Industrial Relations and Personal Management from the London School of Economics, United Kingdom and she read law at the University of Manchester from 1998 - 2001.</p>
			<p>In 2010, Violet published a bestselling book titled "Lessons from 15,000 First Dates" where she shares dating secrets that she learnt after having witnessed 15,000 first dates arranged by her dating agency at that time for thousands of single men and women, and is currently working on her second book.</p>
			<p>Her personal dating blog www.violetlim.com attracts thousands of readers who want to learn about her views on dating and relationship. The blog, known as "Diary of a Modern-Day Matchmaker" has won The Most Insightful Blog at Singapore Blog Awards 2010, which reinforces her as the country's most beloved dating guru.</p>
			<p>Violet is happily married to her university sweetheart cum business partner Jamie, and they have two young children, Corum and Cara. Having been blessed with a fulfilling marriage and enriching family life, Violet's life goal is to create 1,000,000 marriages through the works of Lunch Actually Group!</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>