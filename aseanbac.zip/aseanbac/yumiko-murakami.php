<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>Yumiko Murakami</h1><br/><br/>
		</div>
	</div>
	<div class='row'>
		<div class='span3'>
			<div class="team-member">
				<div class="team-member-thumb">
					<img alt="Yumiko" src="_layout/images/bg-body20.png">
				</div>
				<p>
					<strong>Yumiko Murakami</strong>
					<br>
					Head of OECD Tokyo Centre (Organisation for Economic Cooperation And Development)
					<br/>
				</p>
			</div>
		</div>
		<div class='span9'>
			<p>Since Yumiko joined OECD in 2013 as the head of OECD Tokyo Centre, she has been at the forefront of policy discussions between OECD and governments, businesses and academia in Japan and Asia, covering a wide range of economic policy areas. She has been leading discussions with various stake holders in Japan and Asia, particularly in the areas of Corporate Governance, tax guidelines, gender diversity, education, international trade and innovation. Prior to joining the OECD, Yumiko held a number of leadership positions as a Managing Director at Goldman Sachs and Credit Suisse. Yumiko has diversified professional experiences, ranging from banking in New York and London to UN Peace Keep Operations in Cambodia. Yumiko has an MBA from Harvard University, MA from Stanford University and BA from Sophia University. She is a member of the Japan Advisory Board of Harvard Business School.</p>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>