<?php include "header.php"; ?>
<div id="content">
	<br/><br/>
	<div class="row">
		<div class="span12">
			<h1>ABA 2015 Recipients</h1><br/><br/>
			<table class="table-bordered table-striped" width="100%">
				<thead>
					<tr>
						<th width="246"><strong>ABA Awards</strong></th>
						<th width="132"><strong>Winners (company)</strong></th>
						<th width="186"><strong>Winners (individual)</strong></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Agro-based</td>
						<td><a href="recipients_details.php?type=company&&name=sl-agritech-corporation">SL Agritech Corporation</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Automotive</td>
						<td><a href="recipients_details.php?type=company&&name=drb-hicom">DRB-Hicom Berhad</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Aviation</td>
						<td><a href="recipients_details.php?type=company&&name=airasia">AirAsia Berhad</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; E-ASEAN</td>
						<td><a href="recipients_details.php?type=company&&name=mit">Myanmar Information Technology Pte. Ltd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Electronics</td>
						<td><a href="recipients_details.php?type=company&&name=g-gear">G Gear Co., Ltd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Fisheries</td>
						<td><a href="recipients_details.php?type=company&&name=ql-resources">QL Resources Berhad</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Healthcare</td>
						<td><a href="recipients_details.php?type=company&&name=health-management-international">Health Management International Limited</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Logistics</td>
						<td><a href="recipients_details.php?type=company&&name=lbc-express">LBC Express, Inc.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Rubber-based</td>
						<td><a href="recipients_details.php?type=company&&name=kossan-rubber-industries">Kossan Rubber Industries Bhd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Textiles</td>
						<td><a href="recipients_details.php?type=company&&name=color-silk">Color Silk Co., Ltd</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Tourism</td>
						<td><a href="recipients_details.php?type=company&&name=myanmar-voyages">Myanmar Voyages International Tourism Co.,Ltd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: AEC Priority Integration Sectors Excellence Award &#8211; Wood-based</td>
						<td><a href="recipients_details.php?type=company&&name=pointray">Pointray (Malaysia) Sdn. Bhd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: SME Excellence Award &#8211; Employment</td>
						<td><a href="recipients_details.php?type=company&&name=proeight">ProEight Sdn. Bhd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: SME Excellence Award &#8211; Innovation</td>
						<td><a href="recipients_details.php?type=company&&name=vitrox">ViTrox Technologies Sdn. Bhd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: SME Excellence Award &#8211; Corporate Social Responsibilities</td>
						<td><a href="recipients_details.php?type=company&&name=vg-offshore-containers-international">VG Offshore Containers International (M) Sdn. Bhd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: SME Excellence Award &#8211; Growth</td>
						<td><a href="recipients_details.php?type=company&&name=wise-concetti-limited">Wise Concetti Ltd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: Young Entrepreneur of the Year Award</td>
						<td>Myanma Awba Group</td>
						<td><a href="recipients_details.php?type=individual&&name=u-thadoe-hein">Thadoe Hein</a></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: Woman Entrepreneur of the Year Award</td>
						<td>Kanbawza Bank Ltd.</td>
						<td><a href="recipients_details.php?type=individual&&name=daw-nan-than-htwe">Daw Nan Than Htwe</a></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: Friends of ASEAN Award</td>
						<td><a href="recipients_details.php?type=company&&name=robert-bosch-sea-pte-ltd">Robert Bosch (SEA) Pte. Ltd.</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: Friends of ASEAN Award</td>
						<td><a href="recipients_details.php?type=company&&name=prudential-corporation-asia">Prudential Corporation Asia</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: Friends of ASEAN Award</td>
						<td><a href="recipients_details.php?type=company&&name=michelin">Michelin</a></td>
						<td></td>
					</tr>
					<tr>
						<td>ASEAN Business Awards 2015: ASEAN-BAC ASEAN Lifetime Achievement Award</td>
						<td></td>
						<td><a href="tan-sri-rafidah-aziz.php">Y. Bhg Tan Sri Rafidah Aziz</a></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php include "footer.php"; ?>